"""Synthetic CPU tests validate mechanics; not evidence of corpus training."""
import os,sys,tempfile,unittest,json,csv
os.environ.setdefault('USE_TF','0');os.environ.setdefault('USE_FLAX','0')
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import torch,numpy as np
from transformers import BertConfig,BertModel,BertTokenizerFast
import prepare_data,tokens
from model import Evaluator,contrastive
from train import rng_state,restore_rng,team_loss,save_model,step
from transformers import get_linear_schedule_with_warmup
from common import write,seed_all
def tiny():
 return Evaluator(BertModel(BertConfig(vocab_size=101,hidden_size=24,num_hidden_layers=2,num_attention_heads=4,intermediate_size=48,max_position_embeddings=32,hidden_dropout_prob=.1,attention_probs_dropout_prob=.1),add_pooling_layer=False))
def batch():
 ids=torch.tensor([[2,8,9,3,0],[2,11,12,13,3],[2,14,15,3,0]])
 return dict(input_ids=ids,attention_mask=ids.ne(0).long())
class FakeTokenizer:
 def __call__(self,texts,**kwargs):
  return {'input_ids':[[2]+list(range(4,4+len(t.split())))+[3] for t in texts]}
class Tests(unittest.TestCase):
 def setUp(self):torch.set_num_threads(2);seed_all(42)
 def test_full_encoder_updates_and_outputs_finite(self):
  m=tiny();before={k:v.detach().clone() for k,v in m.encoder.named_parameters()};opt=torch.optim.AdamW(m.parameters(),lr=.01);a=batch()
  p=m(a,a);loss=contrastive(m.embed(a),m.embed(a),torch.arange(3))+.01*sum(v.square().mean() for v in p.values());loss.backward()
  self.assertTrue(all(p.requires_grad for p in m.encoder.parameters()))
  self.assertGreater(sum(p.grad is not None for p in m.encoder.parameters()),0)
  opt.step();self.assertTrue(any(not torch.equal(before[k],v) for k,v in m.encoder.named_parameters()))
  self.assertEqual(set(p),{'rank','fluency','semantic'});self.assertTrue(all(torch.isfinite(x).all() for x in p.values()))
 def test_same_group_is_positive_not_false_negative(self):
  x=torch.eye(3)
  self.assertAlmostEqual(float(contrastive(x,x,torch.zeros(3,dtype=torch.long))),0.,places=6)
 def test_real_step_advances_warmup_and_updates_encoder(self):
  model=tiny();opt=torch.optim.AdamW(model.encoder.parameters(),lr=.001)
  scheduler=get_linear_schedule_with_warmup(opt,2,10);scaler=torch.amp.GradScaler('cuda',enabled=False)
  original={k:v.clone() for k,v in model.encoder.state_dict().items()};a=batch()
  self.assertEqual(opt.param_groups[0]['lr'],0.)
  for _ in range(3):
   loss=contrastive(model.embed(a),model.embed(a),torch.arange(3));loss.backward()
   self.assertTrue(step(opt,scaler,model,1,scheduler))
  self.assertEqual(scheduler.last_epoch,3);self.assertGreater(opt.param_groups[0]['lr'],0.)
  self.assertTrue(any(not torch.equal(v,original[k]) for k,v in model.encoder.state_dict().items()))
 def test_inference_round_trip_and_explicit_length_rejection(self):
  from inference import VietnameseEvaluator
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);vocab=['[PAD]','[UNK]','[CLS]','[SEP]','[MASK]']+['token'+str(i) for i in range(96)]
   (root/'vocab.txt').write_text('\n'.join(vocab),encoding='utf-8')
   tokenizer=BertTokenizerFast(vocab_file=str(root/'vocab.txt'),do_lower_case=False)
   model=tiny().eval()
   save_model(root/'checkpoint',model,tokenizer,dict(token_limit=16,label_origin='synthetic_test_only'))
   scorer=VietnameseEvaluator(root/'checkpoint',device='cpu')
   x=tokenizer('token1 token2',return_tensors='pt')
   with torch.inference_mode():expected=float(model(x,x)['rank'][0])
   got=scorer.score('token1 token2','token1 token2')
   self.assertAlmostEqual(expected,got['rank_score'],places=7)
   self.assertFalse(got['human_validated']);self.assertIsNone(got['grammar_score'])
   with self.assertRaises(ValueError):scorer.score('', 'token1')
   with self.assertRaises(ValueError):scorer.score(' '.join(['token1']*20),'token2')
   del scorer
 def test_quick_validation_uses_one_pair_per_group(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);source=root/'pairs.jsonl'
   write(source,[dict(sample_id=str(i),input_vi='one two',target_vi='two one',group_id='g'+str(i//2)) for i in range(6)])
   with patch.object(tokens,'ROOT',root):
    dataset=tokens.TokenPairs(source,FakeTokenizer(),selected_groups={'g0','g1'},one_per_group=True)
    self.assertEqual(len(dataset),2);del dataset
 def test_resume_restores_next_step_exactly(self):
  m=tiny();opt=torch.optim.AdamW(m.parameters(),lr=.001);a=batch()
  def update(model,optimizer):
   optimizer.zero_grad();loss=model(a,a)['rank'].square().mean();loss.backward();optimizer.step();return loss.detach()
  update(m,opt)
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'state.pt';torch.save({'model':m.state_dict(),'optimizer':opt.state_dict(),'rng':rng_state()},path)
   first=update(m,opt);expected={k:v.clone() for k,v in m.state_dict().items()}
   m2=tiny();o2=torch.optim.AdamW(m2.parameters(),lr=.001);s=torch.load(path,weights_only=False)
   m2.load_state_dict(s['model']);o2.load_state_dict(s['optimizer']);restore_rng(s['rng']);second=update(m2,o2)
   self.assertTrue(torch.equal(first,second));self.assertTrue(all(torch.equal(expected[k],v) for k,v in m2.state_dict().items()))
 def test_missing_axis_targets_do_not_become_zero(self):
  p={'rank':torch.zeros(2,requires_grad=True),'fluency':torch.ones(2,requires_grad=True),'semantic':torch.ones(2,requires_grad=True)}
  y=torch.full((2,4),float('nan'));loss=team_loss(p,p,y,torch.ones(2),torch.zeros(2))
  self.assertTrue(torch.isfinite(loss));self.assertEqual(float(loss),0.)
 def test_token_cache_never_silently_truncates(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);source=root/'pairs.jsonl'
   write(source,[dict(sample_id='a',input_vi='một câu',target_vi='câu khác',group_id='g'),dict(sample_id='b',input_vi=' '.join(['dài']*20),target_vi='khác',group_id='h')])
   with patch.object(tokens,'ROOT',root):
    data=tokens.TokenPairs(source,FakeTokenizer(),limit=8)
    self.assertEqual(len(data),1)
    meta=json.loads((data.cache/'manifest.json').read_text());self.assertEqual(meta['excluded'],1)
    del data
 def test_cross_split_connected_text_is_quarantined(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);(root/'data').mkdir();fields=['original_id','original_text','paraphrase_text','source','topic']
   files={'visp_train.csv':[['i','A','B','x','x'],['j','T','U','x','x']],'visp_val.csv':[['k','A','C','x','x']],'visp_test.csv':[['l','D','E','x','x']]}
   for filename,rows in files.items():
    with (root/filename).open('w',encoding='utf-8',newline='') as f:w=csv.writer(f);w.writerow(fields);w.writerows(rows)
   with patch.object(prepare_data,'ROOT',root),patch.object(prepare_data,'config',lambda:{'visp_expected':{'train':2,'validation':1,'test':1},'visp_revision':'synthetic_fixture'}):
    prepare_data.audit_visp(root)
   m=json.loads((root/'data/visp_manifest.json').read_text());self.assertEqual(m['kept_counts']['train'],1);self.assertEqual(m['cross_split_quarantine']['train'],1)
if __name__=='__main__':unittest.main()
