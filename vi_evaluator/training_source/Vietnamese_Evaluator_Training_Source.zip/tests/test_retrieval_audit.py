import os,sys,unittest
from pathlib import Path
os.environ['USE_TF']='0';os.environ['USE_FLAX']='0';sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import torch
from retrieval_audit import nonidentity_metrics
class IdentityDiagnosticTests(unittest.TestCase):
 def test_reverse_pairs_do_not_get_trivial_identity_credit(self):
  a=torch.tensor([[1.,0.],[-1.,0.],[0.,1.],[0.,-1.]])
  b=a[torch.tensor([1,0,3,2])];g=torch.tensor([0,0,1,1])
  raw=(g[(a@b.T).argmax(1)]==g).float().mean().item()
  self.assertEqual(raw,1.)
  fixed=nonidentity_metrics(a,b,g,torch.tensor([1,2,3,4]),torch.tensor([2,1,4,3]),pool=4)
  self.assertEqual(fixed['r_at_1'],0.);self.assertEqual(fixed['identity_candidates_masked'],4)
  self.assertEqual(fixed['n_evaluated'],4)
if __name__=='__main__':unittest.main()
