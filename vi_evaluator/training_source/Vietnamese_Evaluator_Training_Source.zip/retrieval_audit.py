"""Post-freeze semantic diagnostic excluding exact token-identity candidates."""
import array,hashlib
from common import *
import numpy as np
import torch
from train import construct,amp,device_batch
from tokens import TokenPairs,collate_pairs

def token_hash(ids):
 return int.from_bytes(hashlib.blake2b(array.array('I',ids).tobytes(),digest_size=8).digest(),'little',signed=True)

def nonidentity_metrics(a,b,groups,source_hashes,target_hashes,pool=1024):
 correct=rr=eligible=excluded=masked=0;unique_groups=[];positive_counts=[]
 for i in range(0,len(groups),pool):
  u,v=a[i:i+pool],b[i:i+pool];g=groups[i:i+pool]
  identity=source_hashes[i:i+pool,None].eq(target_hashes[None,i:i+pool])
  scores=u@v.T;positive=g[:,None].eq(g[None,:]) & ~identity
  keep=positive.any(1);excluded+=(~keep).sum().item();masked+=identity.sum().item()
  if not keep.any():continue
  scores=scores.masked_fill(identity,-torch.inf);best=scores.masked_fill(~positive,-torch.inf).max(1).values
  top=scores.argmax(1);correct+=((g[top]==g)&keep).sum().item()
  rank=1+(scores>best[:,None]).sum(1);rr+=(1./rank[keep]).sum().item();eligible+=keep.sum().item()
  unique_groups.append(len(g.unique()));positive_counts.extend(positive.sum(1)[keep].tolist())
 return dict(n_source_rows=len(groups),n_evaluated=eligible,queries_without_nonidentity_positive=excluded,r_at_1=correct/eligible if eligible else None,mrr=rr/eligible if eligible else None,
  pool_size=pool,identity_candidates_masked=masked,mean_distinct_groups_per_pool=float(np.mean(unique_groups)) if unique_groups else None,mean_legal_positive_candidates=float(np.mean(positive_counts)) if positive_counts else None,
  interpretation='Group retrieval after exact token-identity removal. Adjacent paraphrase families remain grouped in pools; this is not human naturalness or translation adequacy.',protocol_origin='post-freeze diagnostic correction; no model tuning uses these scores')

def main():
 device='cuda:0' if torch.cuda.is_available() else 'cpu';model,tok=construct(ROOT/'artifacts/stage_a/complete/encoder');model.to(device).eval()
 for split in ['validation','test']:
  data=TokenPairs(ROOT/f'data/visp_{split}.jsonl',tok,config()['max_tokens']);aa=[];bb=[];gg=[];ah=[];bh=[]
  with torch.inference_mode():
   for start in range(0,len(data),32):
    rows=[data[j] for j in range(start,min(start+32,len(data)))];x,y,g=collate_pairs(rows,tok.pad_token_id)
    with amp(device):a=model.embed(device_batch(x,device));b=model.embed(device_batch(y,device))
    aa.append(a.cpu());bb.append(b.cpu());gg.append(g);ah.extend(token_hash(r[0]) for r in rows);bh.extend(token_hash(r[1]) for r in rows)
    if start and start%50016==0:print('Nonidentity audit',split,start,'/',len(data),flush=True)
  result=nonidentity_metrics(torch.cat(aa),torch.cat(bb),torch.cat(gg),torch.tensor(ah,dtype=torch.int64),torch.tensor(bh,dtype=torch.int64))
  save(ROOT/f'reports/stage_a_{split}_nonidentity.json',result);print('Nonidentity semantic diagnostic',split,result,flush=True)
if __name__=='__main__':main()
