"""Download selected private output artifacts; signed grants remain in memory."""
import argparse,json,hashlib,sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import urljoin
import requests
from common import ROOT,sha,save
def target(entry):
 name=entry['fullPath']
 if not name.startswith('vi_evaluator/'):return None
 relative=name[len('vi_evaluator/'):]
 # Preserve local sources and audited corpus; only retrieve trained outputs.
 if not relative.startswith(('artifacts/','reports/','delivery/','data/token_cache/')) and relative!='private/teacher_cache.jsonl':return None
 if relative.startswith('data/token_cache/') and not relative.endswith(('manifest.json','excluded.jsonl')):return None
 if relative.endswith(('latest.pt','.bin','.npy','.pyc')):return None
 p=(ROOT/relative).resolve()
 if not p.is_relative_to(ROOT.resolve()):raise ValueError('Unsafe output path')
 return p
def download(entry):
 p=target(entry)
 if p is None:return None
 expected_size=int(entry.get('contentLength',0))
 if p.exists() and p.stat().st_size==expected_size and p.suffix in ['.safetensors','.zip']:
  return dict(file=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p),cached=True)
 p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.download')
 for attempt in range(3):
  try:
   h=hashlib.sha256();size=0
   with requests.get(urljoin('https://www.kaggle.com',entry['downloadUrl']),stream=True,timeout=(30,180)) as r:
    if r.status_code!=200:raise RuntimeError('Artifact HTTP '+str(r.status_code))
    with tmp.open('wb') as f:
     for block in r.iter_content(4*1024*1024):f.write(block);h.update(block);size+=len(block)
   if size!=expected_size:raise RuntimeError('Incomplete download')
   tmp.replace(p);print('Downloaded',str(p.relative_to(ROOT)),size,flush=True)
   return dict(file=str(p.relative_to(ROOT)),bytes=size,sha256=h.hexdigest())
  except Exception as error:
   if attempt==2:raise RuntimeError('Download failed for '+str(p.relative_to(ROOT))+': '+type(error).__name__) from None
def main():
 # Supply a single JSON line through stdin; never log or save downloadUrl grants.
 payload=json.loads(sys.stdin.readline())
 if payload['kernelRun']['status']!='COMPLETE':raise RuntimeError('Run is not complete')
 entries=[e for e in payload.get('outputFiles',[]) if target(e)]
 with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(download,entries))
 batch=payload.get('batch_id')
 name='remote_download.json' if batch is None else 'remote_download_batch_'+str(int(batch))+'.json'
 save(ROOT/'verification'/name,dict(script_version_id=payload['kernelRun']['id'],status='COMPLETE',is_private=payload['kernel']['isPrivate'],files=results))
 print('Download complete',len(results),flush=True)
if __name__=='__main__':main()
