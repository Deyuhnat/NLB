"""Additional paired comparisons after model freeze; never tune on fresh sources."""
import collections,gc,pickle,sys
import numpy as np
from common import *
from inference import VietnameseEvaluator
from teacher import Teacher

def clustered_interval(rows,key,left,right):
 by=collections.defaultdict(dict)
 for r in rows:by[r['work_id']].setdefault(r['sample_id'],{})[r['system']]=r[key]
 work_deltas=[]
 for work,samples in sorted(by.items()):
  values=[d[left]-d[right] for d in samples.values() if d.get(left) is not None and d.get(right) is not None]
  if values:work_deltas.append(float(np.mean(values)))
 if not work_deltas:return None
 rng=np.random.default_rng(42);boot=np.mean(rng.choice(work_deltas,(2000,len(work_deltas)),replace=True),axis=1)
 return dict(paired_mean_delta=float(np.mean(work_deltas)),ci95=list(map(float,np.quantile(boot,[.025,.975]))),resampling_unit='work',works=len(work_deltas),bootstrap_replicates=2000,scope='automatic proxy only')

def dev_gate(scorer):
 samples=read(ROOT/'data/team_dev.jsonl');teachers={(r['sample_id'],norm(r['candidate_vi'])):r for r in read(ROOT/'data/team_labels_dev.jsonl')};cache=[]
 for s in samples:
  options=[c['text'] for c in s['candidates']];scores=scorer.score_many([dict(source=s['input_vi'],candidate=t) for t in options])
  copy=next(i for i,t in enumerate(options) if norm(t)==norm(s['input_vi']));best=max(range(len(options)),key=lambda i:scores[i]['rank_score'])
  cache.append((s,options,scores,copy,best))
 search=[]
 for threshold in [0.,.05,.1,.2,.5,1.,1e9]:
  correct=harm=changes=0
  for s,options,scores,copy,best in cache:
   chosen=best if scores[best]['rank_score']-scores[copy]['rank_score']>threshold else copy
   text=options[chosen];correct+=norm(text)==norm(s['reviewed_output_vi'])
   changed=norm(text)!=norm(s['input_vi']);changes+=changed
   if changed:harm+=bool(teachers[s['sample_id'],norm(text)]['proxy_harm'])
  rate=harm/changes if changes else 0.
  if rate<=.05:search.append((correct/len(samples),-rate,-changes,threshold))
 return max(search)[-1]

def main():
 import torch
 torch.set_num_threads(4)
 existing=read(ROOT/'reports/fresh_automatic_scores.jsonl')
 rows=read(ROOT/'data/fresh_test.jsonl');generations={r['sample_id']:r for r in read(ROOT/'reports/fresh_base_generations.jsonl')}
 added=[]
 for name,path in [('new_evaluator_base_pool',ROOT/'artifacts/stage_b/best'),('no_visp_base_pool',ROOT/'artifacts/stage_b_no_visp/best')]:
  scorer=VietnameseEvaluator(path,device='cpu')
  threshold=json.loads((path/'gate.json').read_text())['selected']['threshold'] if (path/'gate.json').exists() else dev_gate(scorer)
  save(ROOT/f'reports/{name}_dev_policy.json',dict(threshold=threshold,selection='dev only',human_validated=False))
  for r in rows:
   options=list(dict.fromkeys([r['input_vi']]+[c['text'] for c in generations[r['sample_id']]['candidates'] if c['complete']]))
   scores=scorer.score_many([dict(source=r['input_vi'],candidate=t) for t in options])
   best=max(range(len(options)),key=lambda j:scores[j]['rank_score'])
   chosen=best if scores[best]['rank_score']-scores[0]['rank_score']>threshold else 0
   added.append(dict(sample_id=r['sample_id'],work_id=r['work_id'],category=r['category'],system=name,input_vi=r['input_vi'],output_vi=options[chosen],context_used=False))
  del scorer;gc.collect()
 # Use only a locally generated trusted pickle from the prior project.
 legacy=ROOT.parent/'vietnamese_benchmark_auto'
 teacher=Teacher(device='cpu')
 if (legacy/'artifacts/M1.pkl').exists():
  sys.path.insert(0,str(legacy))
  import selector
  with (legacy/'artifacts/M1.pkl').open('rb') as f:model=pickle.load(f)
  class Adapter:
   def encode(self,texts):return np.array([teacher.text(t)['vector'] for t in texts],dtype=np.float32)
  for r in rows:
   candidates=[dict(input_vi=r['input_vi'],text=c['text'],idx=i) for i,c in enumerate(generations[r['sample_id']]['candidates']) if c['complete'] and norm(c['text'])!=norm(r['input_vi'])]
   chosen=None
   if candidates:
    x=selector.matrix(candidates,model['vectorizer'],Adapter())
    probabilities=model['classifier'].predict_proba(model['scaler'].transform(x[:,model['columns']]))[:,1]
    chosen=selector.choose(candidates,probabilities,model['threshold'])
   added.append(dict(sample_id=r['sample_id'],work_id=r['work_id'],category=r['category'],system='legacy_M1_base_pool',input_vi=r['input_vi'],output_vi=chosen['text'] if chosen else r['input_vi'],context_used=False))
 for i,r in enumerate(added):
  r.update(teacher.pair(r['input_vi'],r['output_vi']))
  r['changed']=norm(r['input_vi'])!=norm(r['output_vi'])
  if (i+1)%100==0:print('Post-download comparison',i+1,'/',len(added),flush=True)
 combined=existing+added;write(ROOT/'reports/fresh_extended_automatic_scores.jsonl',combined)
 metrics={}
 for system in sorted({r['system'] for r in combined}):
  rr=[r for r in combined if r['system']==system]
  metrics[system]=dict(n=len(rr),changes=sum(r['changed'] for r in rr),mean_fluency_proxy=float(np.mean([r['fluency_target'] for r in rr if r['fluency_target'] is not None])),mean_semantic_proxy=float(np.mean([r['semantic_target'] for r in rr])))
 comparisons=[]
 for left,right in [('new_evaluator_base_pool','no_visp_base_pool'),('new_evaluator_base_pool','base_top1'),('new_evaluator_rerank','finetuned_top1'),('new_evaluator_base_pool','legacy_M1_base_pool')]:
  if right not in metrics:continue
  comparisons.append(dict(left=left,right=right,fluency=clustered_interval(combined,'fluency_target',left,right),semantic=clustered_interval(combined,'semantic_target',left,right)))
 per_category={}
 for category in sorted({r['category'] for r in combined}):
  per_category[category]={}
  for system in metrics:
   rr=[r for r in combined if r['category']==category and r['system']==system]
   per_category[category][system]=dict(n=len(rr),changes=sum(r['changed'] for r in rr),mean_fluency_proxy=float(np.mean([r['fluency_target'] for r in rr if r['fluency_target'] is not None])),mean_semantic_proxy=float(np.mean([r['semantic_target'] for r in rr])))
 save(ROOT/'reports/fresh_extended_comparison.json',dict(systems=metrics,per_category=per_category,paired_comparisons=comparisons,label_origin='automatic_proxy',human_validated=False,warning='Shared teacher supervision makes this an automatic study; human confirmation remains pending. Base-pool comparisons use identical candidates. Rerank with finetuned options uses an expanded pool.'))
 print('Extended comparison complete',flush=True)
if __name__=='__main__':main()
