"""Stream the complete official corpus; retain official splits and quarantine leaks."""
import argparse,csv,json,collections,sqlite3,array
from common import *
class UnionFind:
 def __init__(self):self.ids={};self.parents=array.array('I');self.sizes=array.array('I')
 def node(self,key):
  h=hashlib.sha256(key.encode('utf-8')).digest()
  if h not in self.ids:
   i=len(self.parents);self.ids[h]=i;self.parents.append(i);self.sizes.append(1)
  return self.ids[h]
 def find(self,i):
  while self.parents[i]!=i:self.parents[i]=self.parents[self.parents[i]];i=self.parents[i]
  return i
 def union(self,a,b):
  a,b=self.find(a),self.find(b)
  if a==b:return
  if self.sizes[a]<self.sizes[b]:a,b=b,a
  self.parents[b]=a;self.sizes[a]+=self.sizes[b]

def audit_visp(directory):
 directory=Path(directory);out=ROOT/'data';db=out/'visp_audit.sqlite'
 if db.exists():raise FileExistsError('Audit exists; use a new version rather than overwrite')
 connection=sqlite3.connect(db)
 connection.execute('PRAGMA journal_mode=OFF');connection.execute('PRAGMA synchronous=OFF')
 connection.execute('CREATE TABLE rows (id INTEGER PRIMARY KEY,split TEXT,node INTEGER,a TEXT,b TEXT,orig TEXT,source TEXT,topic TEXT,rowhash TEXT)')
 uf=UnionFind();counts={};excluded=[];expected=config()['visp_expected']
 for split,filename in [('train','visp_train.csv'),('validation','visp_val.csv'),('test','visp_test.csv')]:
  count=0
  with (directory/filename).open(encoding='utf-8-sig',newline='') as f:
   for count,row in enumerate(csv.DictReader(f),1):
    a,b=norm(row['original_text']),norm(row['paraphrase_text'])
    if not a or not b:excluded.append(dict(split=split,row=count,reason='empty'));continue
    node=uf.node('orig:'+row['original_id'])
    uf.union(node,uf.node('text:'+a));uf.union(node,uf.node('text:'+b))
    connection.execute('INSERT INTO rows(split,node,a,b,orig,source,topic,rowhash) VALUES (?,?,?,?,?,?,?,?)',(split,node,a,b,row['original_id'],row.get('source',''),row.get('topic',''),digest(a+'\0'+b)))
    if count%50000==0:connection.commit();print(split,'read',count,flush=True)
  if count!=expected[split]:raise ValueError(f'Unexpected {split} row count {count}, expected {expected[split]}')
  counts[split]=count;connection.commit()
 priority={'train':0,'validation':1,'test':2};owner={}
 for split,node in connection.execute('SELECT split,node FROM rows'):
  root=uf.find(node);owner[root]=max(owner.get(root,-1),priority[split])
 seen=set();kept=collections.Counter();groups=collections.defaultdict(set);leaks=collections.Counter()
 handles={s:(out/f'visp_{s}.jsonl').open('w',encoding='utf-8',newline='\n') for s in priority}
 exclusions=(out/'visp_exclusions.jsonl').open('w',encoding='utf-8',newline='\n')
 for e in excluded:exclusions.write(json.dumps(e)+'\n')
 for idx,split,node,a,b,orig,source,topic,rowhash in connection.execute('SELECT * FROM rows ORDER BY id'):
  group=uf.find(node);reason=None
  if owner[group]!=priority[split]:reason='connected_group_appears_in_higher_priority_split';leaks[split]+=1
  elif (split,rowhash) in seen:reason='duplicate_ordered_pair'
  if reason:exclusions.write(json.dumps(dict(row=idx,split=split,reason=reason))+'\n');continue
  seen.add((split,rowhash));gid='visp-group-'+str(group);groups[split].add(gid);kept[split]+=1
  record=dict(sample_id='visp-row-'+str(idx),group_id=gid,original_id=orig,split=split,source=source,topic=topic,input_vi=a,target_vi=b,reference_origin='ViSP_paraphrase_not_fluency_rating')
  handles[split].write(json.dumps(record,ensure_ascii=False)+'\n')
 for h in handles.values():h.close()
 exclusions.close();connection.close()
 if not kept['train']:raise ValueError('No train records after leakage quarantine')
 assert not(groups['train']&groups['validation'] or groups['train']&groups['test'] or groups['validation']&groups['test'])
 manifest=dict(dataset='ngwgsang/ViSP',revision=config()['visp_revision'],raw_counts=counts,kept_counts=dict(kept),groups={s:len(g) for s,g in groups.items()},cross_split_quarantine=dict(leaks),no_groups_cross_splits=True,split_policy='official splits retained; test > validation > train for shared connected groups; lower-priority records quarantined',raw_files={s:sha(directory/s) for s in ['visp_train.csv','visp_val.csv','visp_test.csv']},files={f'data/visp_{s}.jsonl':sha(out/f'visp_{s}.jsonl') for s in priority})
 save(out/'visp_manifest.json',manifest);print(json.dumps(manifest,ensure_ascii=False,indent=2),flush=True)

def prepare_team(path):
 records=read(path);samples=[];preferences=[];excluded=[];counts=collections.Counter()
 for r in records:
  if r['split']=='pilot' or r.get('source_uncertainty'):
   excluded.append(dict(sample_id=r['sample_id'],split=r['split'],reason='pilot' if r['split']=='pilot' else r['source_uncertainty']));continue
  review=r['review'];source=norm(r['input_vi']);target=norm(review['output_vi'])
  if not source or not target:raise ValueError('Empty team input or target')
  split=r['split'];counts[split]+=1;options=review.get('options') or r['candidates']
  texts=list(dict.fromkeys([source,target]+[norm(c['text']) for c in options if norm(c.get('text'))]))
  sample=dict(sample_id=r['sample_id'],work_id=r['work_id'],group_id=r['group_id'],split=split,input_vi=source,reviewed_output_vi=target,context_vi=r['context_vi'],context_used=False,review_origin=r.get('review_origin'),candidates=[dict(candidate_id=r['sample_id']+':eval:'+str(i),text=t) for i,t in enumerate(texts)])
  samples.append(sample)
  for t in texts:
   if t==target:continue
   preferences.append(dict(sample_id=r['sample_id'],work_id=r['work_id'],split=split,input_vi=source,preferred_vi=target,alternative_vi=t,label_origin='legacy_choice_inferred_preference',review_origin=r.get('review_origin'),human_independently_validated=False))
 for split in ['train','dev','test']:
  write(ROOT/f'data/team_{split}.jsonl',[r for r in samples if r['split']==split])
  write(ROOT/f'data/preferences_{split}.jsonl',[r for r in preferences if r['split']==split])
 if dict(counts)!={'train':697,'dev':141,'test':150}:raise ValueError('Unexpected eligible team split counts')
 write(ROOT/'data/team_exclusions.jsonl',excluded)
 save(ROOT/'data/team_manifest.json',dict(description='Bộ dữ liệu gồm 1.050 câu đã được nhóm review',source_records=len(records),eligible_counts=dict(counts),preferences_by_split=dict(collections.Counter(r['split'] for r in preferences)),source_sha256=sha(path),excluded=len(excluded),labels_are='weak preferences inferred from historical choices, not per-axis human ratings',files={f'data/team_{s}.jsonl':sha(ROOT/f'data/team_{s}.jsonl') for s in counts}))
 print('Prepared team data:',dict(counts),'preferences',len(preferences),flush=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('cmd',choices=['visp','team']);p.add_argument('--source',required=True);a=p.parse_args()
 audit_visp(a.source) if a.cmd=='visp' else prepare_team(a.source)
if __name__=='__main__':main()
