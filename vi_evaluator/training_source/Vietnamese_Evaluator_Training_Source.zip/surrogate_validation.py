"""Measure heldout agreement with automatic teachers, not human naturalness."""
import collections,gc
import numpy as np
from common import *
from inference import VietnameseEvaluator

def correlation(x,y):
 x=np.asarray(x,dtype=float);y=np.asarray(y,dtype=float)
 if len(x)<2 or np.std(x)<1e-12 or np.std(y)<1e-12:return None
 return float(np.corrcoef(x,y)[0,1])
def average_ranks(x):
 _,inverse,counts=np.unique(x,return_inverse=True,return_counts=True)
 return (np.cumsum(counts)-(counts+1)/2)[inverse]
def axis_metrics(rows,prediction,target):
 valid=[r for r in rows if r.get(target) is not None and np.isfinite(r[target]) and np.isfinite(r[prediction])]
 if not valid:return dict(n=0,mae=None,source_macro_mae=None,pearson=None,spearman=None)
 p=np.array([r[prediction] for r in valid]);t=np.array([r[target] for r in valid])
 by=collections.defaultdict(list)
 for r in valid:by[r['sample_id']].append(abs(r[prediction]-r[target]))
 baseline=0. if target=='fluency_target' else 1.
 return dict(n=len(valid),sources=len(by),mae=float(np.mean(np.abs(p-t))),source_macro_mae=float(np.mean([np.mean(v) for v in by.values()])),
  pearson=correlation(p,t),spearman=correlation(average_ranks(p),average_ranks(t)),constant_baseline_value=baseline,constant_baseline_mae=float(np.mean(np.abs(t-baseline))))

def main():
 import torch
 torch.set_num_threads(4)
 path=ROOT/'reports/fresh_extended_automatic_scores.jsonl'
 if not path.exists():path=ROOT/'reports/fresh_automatic_scores.jsonl'
 unique={}
 for r in read(path):
  key=(r['sample_id'],norm(r['input_vi']),norm(r['output_vi']))
  unique.setdefault(key,dict(sample_id=r['sample_id'],work_id=r['work_id'],source=r['input_vi'],candidate=r['output_vi'],fluency_target=r['fluency_target'],semantic_target=r['semantic_target'],changed=norm(r['input_vi'])!=norm(r['output_vi'])))
 rows=list(unique.values());summary={};output=[]
 for name,checkpoint in [('full_visp_team',ROOT/'artifacts/stage_b/best'),('team_only_ablation',ROOT/'artifacts/stage_b_no_visp/best')]:
  scorer=VietnameseEvaluator(checkpoint,device='cpu');pred=scorer.score_many(rows,batch_size=16)
  scored=[dict(**r,fluency_prediction=p['fluency_delta_proxy'],semantic_prediction=p['semantic_preservation_proxy'],model=name) for r,p in zip(rows,pred)]
  summary[name]={}
  for subset,selected in [('all_unique_pairs',scored),('edited_candidates_only',[r for r in scored if r['changed']])]:
   summary[name][subset]=dict(fluency=axis_metrics(selected,'fluency_prediction','fluency_target'),semantic=axis_metrics(selected,'semantic_prediction','semantic_target'))
  output.extend(scored);del scorer;gc.collect()
 write(ROOT/'reports/surrogate_predictions.jsonl',output)
 save(ROOT/'reports/surrogate_teacher_agreement.json',dict(results=summary,unique_pairs=len(rows),duplicate_policy='one record per source sample and normalized candidate, regardless of how many systems emitted it',label_origin='shared_automatic_teacher',human_validated=False,interpretation='Exploratory agreement with the same teacher family used for supervision; not independent human validation. Models and thresholds are frozen; this script performs evaluation only.'))
 print('Heldout surrogate agreement complete',len(rows),'unique pairs',flush=True)
if __name__=='__main__':main()
