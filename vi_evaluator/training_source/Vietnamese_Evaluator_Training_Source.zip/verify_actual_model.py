"""Actual downloaded checkpoint reload, GPU/CPU parity, and HTTP API checks."""
import math,os,socket,subprocess,sys,time
import requests
from common import *
import torch,transformers
from inference import VietnameseEvaluator
from train import state_hash

def main():
 torch.set_num_threads(4);checkpoint=ROOT/'artifacts/stage_b/best'
 freeze=json.loads((ROOT/'reports/model_freeze.json').read_text(encoding='utf-8'))
 for name,h in freeze['files'].items():
  if sha(checkpoint/name)!=h:raise ValueError('Downloaded frozen file changed: '+name)
 a=json.loads((ROOT/'artifacts/stage_a/training_proof.json').read_text())
 b=json.loads((checkpoint/'model_card.json').read_text())
 assert a['before_sha256']!=a['after_sha256']
 assert b['encoder_before_sha256']==a['after_sha256']
 assert b['encoder_before_sha256']!=b['encoder_after_sha256']
 started=time.perf_counter();scorer=VietnameseEvaluator(checkpoint,device='cpu');load_seconds=time.perf_counter()-started
 actual=state_hash(scorer.model.encoder)
 if actual!=b['encoder_after_sha256']:raise ValueError('Reloaded encoder state differs from training proof')
 golden=read(ROOT/'reports/team_dev_scores.jsonl');chosen=[golden[i] for i in [0,len(golden)//2,len(golden)-1]]
 pairs=[dict(source=r['source'],candidate=r['candidate']) for r in chosen]
 started=time.perf_counter();pred=scorer.score_many(pairs);score_seconds=time.perf_counter()-started
 keys=['rank_score','fluency_delta_proxy','semantic_preservation_proxy'];differences={}
 for key in keys:
  differences[key]=max(abs(p[key]-r[key]) for p,r in zip(pred,chosen))
  if not all(math.isfinite(p[key]) for p in pred):raise ValueError('Nonfinite prediction')
 if max(differences.values())>1e-4:raise ValueError('CPU/GPU numerical difference exceeds 1e-4')
 save(ROOT/'verification/real_model_reload.json',dict(passed=True,torch_version=torch.__version__,transformers_version=transformers.__version__,device='cpu',encoder_sha256=actual,encoder_parameters=sum(p.numel() for p in scorer.model.encoder.parameters()),samples=len(pairs),cpu_gpu_max_abs_difference=differences,tolerance=1e-4,load_seconds=load_seconds,score_wall_seconds=score_seconds,human_validated=False,context_used=False))
 with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
 env=os.environ.copy();env['VI_EVALUATOR_CHECKPOINT']=str(checkpoint)
 command=[sys.executable,'-m','uvicorn','api:app','--host','127.0.0.1','--port',str(port),'--log-level','warning']
 process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
 origin=f'http://127.0.0.1:{port}'
 try:
  for attempt in range(90):
   if process.poll() is not None:raise RuntimeError('API failed to start: '+process.stdout.read()[-2000:])
   try:
    if requests.get(origin+'/openapi.json',timeout=2).status_code==200:break
   except requests.RequestException:pass
   time.sleep(1)
  else:raise RuntimeError('API startup timeout')
  good=requests.post(origin+'/score',json=pairs[0],timeout=180)
  empty=requests.post(origin+'/score',json=dict(source='',candidate='một câu'),timeout=20)
  long=requests.post(origin+'/score',json=dict(source='word '*700,candidate='một câu'),timeout=20)
  assert good.status_code==200 and empty.status_code==422 and long.status_code==422
  body=good.json();assert body['human_validated'] is False and body['grammar_score'] is None and body['context_used'] is False
  assert all(math.isfinite(body[k]) for k in keys)
  save(ROOT/'verification/api_smoke.json',dict(passed=True,valid_status=good.status_code,empty_status=empty.status_code,overlength_status=long.status_code,response=body,endpoint='POST /score',scope='actual trained model over local HTTP',human_validated=False))
 finally:
  process.terminate()
  try:process.wait(timeout=10)
  except subprocess.TimeoutExpired:process.kill();process.wait(timeout=10)
 print('ACTUAL MODEL RELOAD + HTTP API VERIFIED',differences,flush=True)
if __name__=='__main__':main()
