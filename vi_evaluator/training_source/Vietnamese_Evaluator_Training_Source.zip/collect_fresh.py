"""Collect new works from the same public source; model-output-blind sampling."""
import argparse,random,re,time,json,collections
from urllib.parse import urljoin,urlparse
from difflib import SequenceMatcher
import requests
from bs4 import BeautifulSoup
from common import *
SEED=42
CATEGORIES=['Tiên hiệp','Kỳ ảo','Huyền huyễn']
filehash=sha
PROJECT=ROOT/'private/exclusions'
def validate_split(rows,old):
 oldworks={r['work_id'] for r in old};oldtexts={norm(r['input_vi']).casefold() for r in old}
 assert not oldworks & {r['work_id'] for r in rows}
 assert not oldtexts & {norm(r['input_vi']).casefold() for r in rows}
 assert len({r['sample_id'] for r in rows})==len(rows)
 assert len({norm(r['input_vi']).casefold() for r in rows})==len(rows)
 seen={}
 for r in rows:
  assert seen.setdefault(r['work_id'],r['split'])==r['split']
 return True

BASE='https://truyendichai.top'
def fetch(url):
 key=digest(url);cache=ROOT/'private/source_cache'/f'{key}.html'
 if cache.exists():text=cache.read_text(encoding='utf-8')
 else:
  r=requests.get(url,timeout=35);r.raise_for_status();text=r.text
  cache.parent.mkdir(parents=True,exist_ok=True);cache.write_text(text,encoding='utf-8');time.sleep(.3)
 return BeautifulSoup(text,'html.parser'),key

def similar(t,others):
 t=norm(t).casefold()
 for other in others:
  if min(len(t),len(other))/max(len(t),len(other))<.85:continue
  if SequenceMatcher(None,t,other,autojunk=False).ratio()>=.90:return True
 return False

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--force',action='store_true');a=ap.parse_args()
 if (ROOT/'data/fresh_test.jsonl').exists() and not a.force:raise FileExistsError('Test already sampled')
 old=json.loads((PROJECT/'vi_selector/data/snapshot.json').read_text(encoding='utf-8'))
 excluded={r['work_id'] for r in old['works']};oldtexts=[norm(r['input_vi']).casefold() for r in old['samples']]
 rng=random.Random(SEED);rows=[];works=[];rejections=[]
 for cat,slug in zip(CATEGORIES,['tien-hiep','ky-ao','huyen-huyen']):
  pages=[fetch(BASE+'/danh-muc/'+slug+'?page='+str(i))[0] for i in range(2,7)];links=list(dict.fromkeys(urljoin(BASE,x['href']) for page in pages for x in page.select('a.work-title[href]')));rng.shuffle(links);count=0
  for url in links:
   wid=urlparse(url).path.strip('/')
   if wid in excluded:continue
   try:
    wp,_=fetch(url);title=wp.select_one('h1');title=title.get_text(' ',strip=True) if title else wid
    anchors=[x for x in wp.select('a[href]') if x.get_text(' ',strip=True)=='Đọc từ đầu' and '/chuong-' in x['href']]
    if not anchors:raise ValueError('No first chapter')
    first=urljoin(BASE,anchors[0]['href']);cp,_=fetch(first)
    chapter_links=list(dict.fromkeys([first]+[urljoin(BASE,x['href']) for x in cp.select('.chapter-queue-item[href]')]))
    rng.shuffle(chapter_links);pool=[]
    for chapter in chapter_links[:3]:
     soup,cache_key=fetch(chapter);article=soup.select_one('.chapter-reader-content article')
     if article is None:raise ValueError('Missing article')
     paras=[norm(x.get_text(' ',strip=True)) for x in article.select('p')]
     if not paras:paras=[norm(x) for x in article.get_text('\n',strip=True).splitlines()]
     sentences=[]
     for pi,para in enumerate(paras):
      for si,match in enumerate(re.finditer(r'.+?(?:[.!?…]+[”’"\u00bb]*\s+|$)',para)):
       text=norm(match.group())
       if text:sentences.append((pi,si,text,match.start(),match.end()))
     for j,(pi,si,text,st,en) in enumerate(sentences):
      if not 45<=len(text)<=350 or len(text.split())<9:continue
      # Fixed source-quality exclusions, applied before any model output exists.
      if re.search(r'https?://|đọc truyện|ủng hộ|truyendich|tác giả|chương \d+',text,re.I):continue
      before=sentences[j-1][2] if j else '';after=sentences[j+1][2] if j+1<len(sentences) else ''
      if not before and not after:continue
      pool.append(dict(sample_id='vb-'+digest(chapter+f':{pi}:{si}')[:20],work_id=wid,work_title=title,category=cat,input_vi=text,context_vi='Trước câu: '+before+'\nSau câu: '+after,source_url=chapter,paragraph_index=pi,sentence_index=si,input_span=[st,st+len(text)],input_span_basis='NFC-normalized paragraph; Unicode code-point offsets',chapter_title=soup.select_one('h1').get_text(' ',strip=True) if soup.select_one('h1') else chapter.rsplit('/',1)[-1],source_cache_sha256=filehash(ROOT/'private/source_cache'/f'{cache_key}.html'),rights_status='unverified',annotation_status='pending'))
    rng.shuffle(pool);chosen=[]
    target=10 if count==0 else 20;split='pilot' if count==0 else 'test'
    for r in pool:
     if similar(r['input_vi'],oldtexts+[norm(x['input_vi']).casefold() for x in rows+chosen]):continue
     r['split']=split;chosen.append(r)
     if len(chosen)==target:break
    if len(chosen)!=target:raise ValueError(f'Only {len(chosen)} eligible unique sentences')
    rows+=chosen;works.append({'work_id':wid,'title':title,'category':cat,'split':split,'source_url':url,'sentences':target});excluded.add(wid);count+=1
    print(cat,count,wid,flush=True)
    if count==5:break
   except (requests.RequestException,ValueError) as e:rejections.append({'url':url,'reason':str(e)})
  if count!=5:raise RuntimeError(f'Insufficient new works: {cat} {count}/5; no partial test written')
 validate_split(rows,old['samples'])
 for split in ['pilot','test']:write(ROOT/f'data/fresh_{split}.jsonl',[r for r in rows if r['split']==split])
 save(ROOT/'private/fresh_collection_manifest.json',{'seed':42,'sampling':'3 seeded chapter selections from first chapter queue; eligible sentences shuffled before model generation','near_duplicate_threshold':.90,'works':works,'rejections':rejections,'files':{s:filehash(ROOT/f'data/fresh_{s}.jsonl') for s in ['pilot','test']},'rights_status':'unverified; internal coursework only'})
 print('Collected 30 pilot / 240 test across 15 fresh works; sampling precedes model outputs.')
if __name__=='__main__':main()
