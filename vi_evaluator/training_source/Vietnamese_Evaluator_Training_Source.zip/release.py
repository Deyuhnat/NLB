"""Build handoff only after downloaded weights pass actual reload/API checks."""
import datetime,shutil,zipfile
from pathlib import PurePosixPath
from common import *

def verify_zip(path):
 with zipfile.ZipFile(path) as z:
  names=z.namelist()
  if len(names)!=len(set(names)):raise ValueError('Duplicate archive entries')
  for name in names:
   p=PurePosixPath(name)
   if p.is_absolute() or '..' in p.parts:raise ValueError('Unsafe archive entry')
  manifest=json.loads(z.read('inference_manifest.json'))
  for name,h in manifest.items():
   digestor=hashlib.sha256()
   with z.open(name) as f:
    for block in iter(lambda:f.read(4*1024*1024),b''):digestor.update(block)
   if digestor.hexdigest()!=h:raise ValueError('Archive hash mismatch: '+name)
 return dict(entries=len(names),verified_hashes=len(manifest),duplicates=0)

def main():
 for name in ['real_model_reload.json','api_smoke.json']:
  p=ROOT/'verification'/name
  if not p.exists() or not json.loads(p.read_text(encoding='utf-8')).get('passed'):raise RuntimeError('Pending actual verification: '+name)
 if not (ROOT/'reports/fresh_extended_comparison.json').exists():raise RuntimeError('Pending extended paired comparison')
 if not (ROOT/'reports/surrogate_teacher_agreement.json').exists():raise RuntimeError('Pending heldout surrogate agreement')
 from package import main as repack
 repack()
 inference=ROOT/'delivery/Vietnamese_Evaluator_Inference.zip';zip_proof=verify_zip(inference)
 source=ROOT/'delivery/Vietnamese_Evaluator_Training_Source.zip'
 source_files=list(ROOT.glob('*.py'))+[ROOT/'config.json',ROOT/'requirements.txt',ROOT/'README.md']
 source_files+=list((ROOT/'tests').glob('*.py'))+list((ROOT/'examples').glob('*.jsonl'))
 source_files+=[ROOT/'delivery/Vietnamese_Evaluator_Kaggle.ipynb',ROOT/'delivery/evaluator_source_bundle.zip']
 with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(set(source_files)):z.write(p,str(p.relative_to(ROOT)).replace('\\','/'))
 shutil.copyfile(source,ROOT/'delivery/EVALUATOR_IMPLEMENTATION_SOURCE.zip')
 run=json.loads((ROOT/'verification/kaggle_run.json').read_text(encoding='utf-8'))
 gate=json.loads((ROOT/'artifacts/stage_b/best/gate.json').read_text(encoding='utf-8'))['selected']
 note=f"""BÀN GIAO VIETNAMESE EVALUATOR

Bộ dữ liệu gồm 1.050 câu đã được nhóm review

Model này chấm câu, dùng kèm model ViSP sinh câu đã bàn giao trước đó.
Foundation: 365.311 cặp train ViSP hợp lệ. Adaptation: 697 nguồn train nhóm,
141 dev, 150 test lịch sử. Đã đánh giá tự động trên 240 câu từ 12 truyện mới.

Có trong gói:
- checkpoint/: encoder, heads, gate và model card.
- inference.py, api.py, requirements.txt, README.md: chạy chấm/API.
- examples/: ví dụ input tự tạo, không phải benchmark.
- reports/: báo cáo HTML, metrics, dữ liệu đánh giá tự động và giới hạn.
- training_proof/: bằng chứng huấn luyện.
- training_source/: source và notebook tái huấn luyện, kèm dữ liệu nhóm đã khóa.
- verification/: kiểm tra model thật, API và nguồn Kaggle.

Đọc README.md và reports/BAO_CAO_BAN_GIAO.html trước khi tích hợp.
Gate hiện tại sửa {gate['changes']} nguồn dev; ngưỡng={gate['threshold']}.
Các điểm là proxy tự động, chưa có xác nhận độc lập bởi người đọc.
JFLEG/SEEDA là cơ sở thiết kế đánh giá, không phải tên hai model được retrain.

Kaggle version: {run.get('script_version_id')}
"""
 note += "\nGIỚI HẠN CHẤT LƯỢNG: Head semantic chưa vượt baseline hằng trên test.\nKhông khuyến nghị dùng evaluator này làm metric chính ở phiên bản hiện tại.\nGate giữ câu gốc trên toàn bộ dev và test mới. teacher.py cung cấp điểm\ntham chiếu tự động; các điểm này vẫn chưa được người đọc xác nhận.\n"
 handoff=ROOT/'delivery/BAN_GIAO_EVALUATOR_VISP_TEAM_20261118.zip'
 verification_files=['real_model_reload.json','api_smoke.json','kaggle_run.json','prior_generator_preserved.json']
 with zipfile.ZipFile(handoff,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out,zipfile.ZipFile(inference) as inp:
  for info in inp.infolist():
   with inp.open(info) as src,out.open(info.filename,'w',force_zip64=True) as dst:shutil.copyfileobj(src,dst,4*1024*1024)
  out.writestr('BAN_GIAO.txt',note)
  out.write(source,'training_source/'+source.name,compress_type=zipfile.ZIP_STORED)
  for name in verification_files:
   p=ROOT/'verification'/name
   if p.exists():out.write(p,'verification/'+name)
 release=dict(created_local=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=7))).isoformat(),model_source_run=run.get('script_version_id'),human_validated=False,zip_validation=zip_proof,files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in [handoff,inference,source]})
 save(ROOT/'delivery/RELEASE_MANIFEST.json',release);print('HANDOFF VERIFIED',handoff.stat().st_size,flush=True)
if __name__=='__main__':main()
