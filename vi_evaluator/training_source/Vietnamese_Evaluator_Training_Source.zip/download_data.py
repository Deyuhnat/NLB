"""Fetch pinned public ViSP CSVs and reproduce the locally audited manifest."""
import requests,time
from common import *
from prepare_data import audit_visp
def main():
 expected=json.loads((ROOT/'data/visp_expected_manifest.json').read_text(encoding='utf-8'));out=ROOT/'data'
 for name,h in expected['raw_files'].items():
  p=out/name
  if p.exists() and sha(p)==h:continue
  url=f"https://huggingface.co/datasets/ngwgsang/ViSP/resolve/{config()['visp_revision']}/{name}"
  for attempt in range(4):
   try:
    with requests.get(url,stream=True,timeout=(30,180)) as r:
     r.raise_for_status()
     with p.with_suffix('.part').open('wb') as f:
      for block in r.iter_content(4*1024*1024):f.write(block)
    p.with_suffix('.part').replace(p)
    if sha(p)!=h:raise ValueError('Pinned download hash mismatch: '+name)
    print('Downloaded and verified',name,p.stat().st_size,flush=True);break
   except Exception:
    if attempt==3:raise
    time.sleep(2*(attempt+1))
 # An intact audited workspace can be resumed without rebuilding its SQLite audit.
 reused=False
 if (out/'visp_manifest.json').exists():
  previous=json.loads((out/'visp_manifest.json').read_text(encoding='utf-8'))
  if previous.get('files')==expected['files'] and all((ROOT/p).exists() and sha(ROOT/p)==h for p,h in expected['files'].items()):
   reused=True;print('Reusing intact audited corpus',flush=True)
 if not reused:audit_visp(out)
 actual=verify(out/'visp_manifest.json')
 for key in ['raw_counts','kept_counts','groups','files','raw_files']:
  if actual[key]!=expected[key]:raise ValueError('Local/Kaggle audit drift: '+key)
 verify(out/'team_manifest.json');verify(out/'teacher_manifest.json')
 print('Public corpus and team manifests verified',flush=True)
if __name__=='__main__':main()
