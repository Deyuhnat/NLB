"""Freeze dev-selected gate before historical test; test never chooses thresholds."""
import argparse,collections,json,math
from common import *
from inference import VietnameseEvaluator

def score_split(scorer,split):
 rows=read(ROOT/f'data/team_{split}.jsonl');flat=[]
 for r in rows:
  for c in r['candidates']:flat.append(dict(sample_id=r['sample_id'],source=r['input_vi'],candidate=c['text'],preferred=r['reviewed_output_vi'],work_id=r['work_id']))
 scored=scorer.score_many(flat)
 result=[dict(**r,**s) for r,s in zip(flat,scored)]
 write(ROOT/f'reports/team_{split}_scores.jsonl',result);return result

def choose(rows,threshold):
 by=collections.defaultdict(list)
 for r in rows:by[r['sample_id']].append(r)
 selected=[]
 for sid,items in by.items():
  original=next(r for r in items if norm(r['source'])==norm(r['candidate']))
  best=max(items,key=lambda r:r['rank_score'])
  chosen=best if best['rank_score']-original['rank_score']>threshold else original
  selected.append(dict(sample_id=sid,work_id=chosen['work_id'],input_vi=chosen['source'],output_vi=chosen['candidate'],reviewed_output_vi=chosen['preferred'],changed=norm(chosen['source'])!=norm(chosen['candidate']),weak_choice_match=norm(chosen['candidate'])==norm(chosen['preferred'])))
 return selected

def calibrate():
 out=ROOT/'artifacts/stage_b/best';scorer=VietnameseEvaluator(out);dev=score_split(scorer,'dev')
 teachers={(r['sample_id'],norm(r['candidate_vi'])):r for r in read(ROOT/'data/team_labels_dev.jsonl')}
 grid=[]
 for threshold in [0.,.05,.1,.2,.5,1.,1e9]:
  selection=choose(dev,threshold);changed=[r for r in selection if r['changed']]
  harm=sum(bool(teachers[r['sample_id'],norm(r['output_vi'])]['proxy_harm']) for r in changed)
  grid.append(dict(threshold=threshold,weak_choice_match=sum(r['weak_choice_match'] for r in selection)/len(selection),changes=len(changed),teacher_harm_count=harm,teacher_harm_rate=harm/len(changed) if changed else 0.))
 eligible=[r for r in grid if r['teacher_harm_rate']<=.05]
 winner=max(eligible,key=lambda r:(r['weak_choice_match'],-r['teacher_harm_rate'],-r['changes'],r['threshold']))
 policy=dict(selected=winner,grid=grid,selection_split='dev_only',label_origin='automatic_teacher_and_historical_choice',human_validated=False,policy='rank margin over copy; teacher harm cap 5% on dev; ties favor fewer edits')
 save(out/'gate.json',policy);save(ROOT/'reports/dev_calibration.json',policy)
 freeze={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file()}
 save(ROOT/'reports/model_freeze.json',dict(files=freeze,checkpoint=str(out),test_access='after this freeze',human_validated=False))
 test=score_split(scorer,'test');selected=choose(test,winner['threshold']);write(ROOT/'reports/team_test_selected.jsonl',selected)
 save(ROOT/'reports/team_test_retrospective.json',dict(n=len(selected),weak_choice_match=sum(r['weak_choice_match'] for r in selected)/len(selected),changed=sum(r['changed'] for r in selected),status='retrospective historical test; previous experiments have inspected these sources; not a new independent test',label_origin='legacy_inferred_preference',human_validated=False))
 print('Dev calibration and retrospective test complete',winner,flush=True)

if __name__=='__main__':calibrate()
