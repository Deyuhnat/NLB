"""Package only verified model files; distinguish training completion from validation."""
import datetime,zipfile
from common import *
def main():
 required=['stage_a/training_proof.json','stage_b/training_proof.json','stage_b_no_visp/training_proof.json','stage_b/best/gate.json']
 for name in required:
  if not (ROOT/'artifacts'/name).exists():raise RuntimeError('Training incomplete: '+name)
 proofs={name:json.loads((ROOT/'artifacts'/name).read_text()) for name in required}
 card=json.loads((ROOT/'artifacts/stage_b/best/model_card.json').read_text())
 if card['encoder_before_sha256']==card['encoder_after_sha256']:raise ValueError('Unchanged stage B encoder')
 files=[]
 for p in (ROOT/'artifacts/stage_b/best').rglob('*'):
  if p.is_file():files.append((p,'checkpoint/'+str(p.relative_to(ROOT/'artifacts/stage_b/best')).replace('\\','/')))
 for name in ['common.py','model.py','inference.py','api.py','teacher.py','requirements.txt','config.json','README.md']:
  if not (ROOT/name).exists():continue
  files.append((ROOT/name,name))
 for p in (ROOT/'reports').glob('*'):
  if p.is_file():files.append((p,'reports/'+p.name))
 for p in (ROOT/'artifacts').glob('*/training_proof.json'):files.append((p,'training_proof/'+p.parent.name+'.json'))
 status=dict(training_complete=True,artifact_kind='Vietnamese evaluator, separate from ViSP generator',stage_a_rows=proofs['stage_a/training_proof.json']['trained_rows'],team_train_sources=697,dev_sources=141,historical_test_sources=150,human_validated=False,context_used=False,official_JFLEG=False,official_SEEDA=False,fresh_pipeline_evaluation='pending unless fresh_pipeline_report.json exists',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 status['fresh_pipeline_evaluation']='completed_automatic_only' if (ROOT/'reports/fresh_pipeline_report.json').exists() else 'pending'
 save(ROOT/'reports/run_status.json',status);files.append((ROOT/'reports/run_status.json','reports/run_status.json'))
 for p in (ROOT/'examples').glob('*.jsonl'):files.append((p,'examples/'+p.name))
 # Repackaging must remain idempotent when run_status already exists.
 files=[(p,name) for name,p in sorted({name:p for p,name in files}.items())]
 manifest={name:sha(p) for p,name in files};save(ROOT/'delivery/inference_manifest.json',manifest)
 target=ROOT/'delivery/Vietnamese_Evaluator_Inference.zip'
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for p,name in files:z.write(p,name)
  z.write(ROOT/'delivery/inference_manifest.json','inference_manifest.json')
 save(ROOT/'delivery/output_manifest.json',dict(files={str(p.relative_to(ROOT)):sha(p) for p in [target,ROOT/'delivery/inference_manifest.json',ROOT/'reports/run_status.json']},package_bytes=target.stat().st_size))
 print('Verified inference package',target.stat().st_size,flush=True)
if __name__=='__main__':main()
