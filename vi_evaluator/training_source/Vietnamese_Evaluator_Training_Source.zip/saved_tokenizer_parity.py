"""Verify base and exported tokenizers on all actual study text; no weight updates."""
from common import *
import transformers,tokenizers
from transformers import AutoTokenizer
def main():
 c=config();base=AutoTokenizer.from_pretrained(c['encoder'],revision=c['encoder_revision']);texts=[]
 for split in ['train','dev','test']:
  for r in read(ROOT/f'data/team_{split}.jsonl'):texts.extend([r['input_vi']]+[x['text'] for x in r['candidates']])
 for split in ['pilot','test']:texts.extend(r['input_vi'] for r in read(ROOT/f'data/fresh_{split}.jsonl'))
 texts=list(dict.fromkeys(texts));results={}
 for stage in ['stage_a/complete','stage_b/best','stage_b_no_visp/best']:
  tok=AutoTokenizer.from_pretrained(ROOT/'artifacts'/stage/'encoder',local_files_only=True);mismatches=[]
  for start in range(0,len(texts),128):
   chunk=texts[start:start+128];a=base(chunk,truncation=False)['input_ids'];b=tok(chunk,truncation=False)['input_ids']
   mismatches.extend(start+i for i,(x,y) in enumerate(zip(a,b)) if x!=y)
  results[stage]=dict(texts_checked=len(texts),token_mismatches=len(mismatches),mismatch_indices=mismatches,serialized_backend_equal=base.backend_tokenizer.to_str()==tok.backend_tokenizer.to_str())
  if mismatches:raise ValueError('Exported tokenizer differs on actual study text: '+stage)
 report=dict(transformers_version=transformers.__version__,tokenizers_version=tokenizers.__version__,backend_model=json.loads(base.backend_tokenizer.to_str())['model']['type'],stages=results)
 save(ROOT/'reports/saved_tokenizer_parity.json',report);print('EXPORTED TOKENIZER PARITY PASSED',report,flush=True)
if __name__=='__main__':main()
