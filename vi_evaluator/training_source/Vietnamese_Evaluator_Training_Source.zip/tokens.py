"""Streaming compact token cache; texts exceeding the limit are excluded explicitly."""
import array,collections,json
import numpy as np
import torch
from common import *
class TokenPairs(torch.utils.data.Dataset):
 def __init__(self,path,tokenizer,limit=512,selected_groups=None,one_per_group=False):
  source=Path(path);selection='all' if selected_groups is None else digest('\n'.join(sorted(selected_groups)))[:12]
  if one_per_group:selection+='-one-per-group'
  cache=ROOT/'data/token_cache'/f'{source.stem}_{selection}_{limit}';cache.mkdir(parents=True,exist_ok=True)
  manifest=cache/'manifest.json'
  expected=dict(source_sha256=sha(source),tokenizer_revision=config()['encoder_revision'],max_tokens=limit,selection=selection)
  if manifest.exists():
   old=json.loads(manifest.read_text(encoding='utf-8'))
   if any(old[k]!=v for k,v in expected.items()):raise ValueError('Token cache identity mismatch')
  else:
   offsets=[];positions=[0,0];groups={};excluded=[];count=0
   with (cache/'a.bin').open('wb') as af,(cache/'b.bin').open('wb') as bf,source.open(encoding='utf-8') as src:
    batch=[];selected_seen=set()
    def flush(rows):
     nonlocal count
     if not rows:return
     aa=tokenizer([r['input_vi'] for r in rows],truncation=False,add_special_tokens=True)['input_ids']
     bb=tokenizer([r['target_vi'] for r in rows],truncation=False,add_special_tokens=True)['input_ids']
     for r,a,b in zip(rows,aa,bb):
      count+=1
      if max(len(a),len(b))>limit:excluded.append(dict(sample_id=r['sample_id'],reason='token_limit',a_tokens=len(a),b_tokens=len(b)));continue
      g=r['group_id'];gi=groups.setdefault(g,len(groups))
      offsets.append([positions[0],len(a),positions[1],len(b),gi])
      array.array('I',a).tofile(af);array.array('I',b).tofile(bf)
      positions[0]+=len(a);positions[1]+=len(b)
     if count%50000<len(rows):print('Tokenized',source.stem,count,flush=True)
    for line in src:
     r=json.loads(line)
     if selected_groups is not None and r['group_id'] not in selected_groups:continue
     if one_per_group and r['group_id'] in selected_seen:continue
     selected_seen.add(r['group_id'])
     batch.append(r)
     if len(batch)>=1024:flush(batch);batch=[]
    flush(batch)
   np.save(cache/'offsets.npy',np.array(offsets,dtype=np.int64))
   save(cache/'groups.json',groups);write(cache/'excluded.jsonl',excluded)
   save(manifest,{**expected,'visited':count,'kept':len(offsets),'excluded':len(excluded)})
  self.cache=cache;self.offsets=np.load(cache/'offsets.npy',mmap_mode='r')
  if not len(self.offsets):raise ValueError('No eligible token pairs')
  self.a=np.memmap(cache/'a.bin',dtype=np.uint32,mode='r');self.b=np.memmap(cache/'b.bin',dtype=np.uint32,mode='r')
 def __len__(self):return len(self.offsets)
 def __getitem__(self,i):
  a,n,b,m,g=map(int,self.offsets[i])
  return list(map(int,self.a[a:a+n])),list(map(int,self.b[b:b+m])),g
def collate_pairs(rows,pad):
 def pack(which):
  seq=[r[which] for r in rows];n=max(map(len,seq));ids=torch.full((len(rows),n),pad,dtype=torch.long);mask=torch.zeros_like(ids)
  for i,s in enumerate(seq):ids[i,:len(s)]=torch.tensor(s);mask[i,:len(s)]=1
  return dict(input_ids=ids,attention_mask=mask)
 return pack(0),pack(1),torch.tensor([r[2] for r in rows],dtype=torch.long)
def select_validation(path,n=5000):
 # One deterministic group reservoir per source/topic, then equal round-robin.
 strata=collections.defaultdict(dict)
 with Path(path).open(encoding='utf-8') as f:
  for line in f:
   r=json.loads(line);g=r['group_id'];key=(r['source'],r['topic'])
   strata[key].setdefault(g,digest('42:'+g))
 ordered={k:iter(sorted(v,key=v.get)) for k,v in sorted(strata.items())};result=[]
 while ordered and len(result)<n:
  for k in list(ordered):
   try:result.append(next(ordered[k]))
   except StopIteration:del ordered[k]
   if len(result)==n:break
 return set(result)
