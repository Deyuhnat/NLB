"""Evaluate a frozen evaluator on new Vietnamese works; automatic evidence only."""
import gc,math,statistics
from common import *
import torch
from transformers import AutoTokenizer,AutoModelForSeq2SeqLM
from inference import VietnameseEvaluator
from teacher import Teacher
BASE='ngwgsang/vit5-base-visp-s1'
REV='ff75dba118e7a175142d5daa9b893b44229c1f55'
def generate(rows,name,model_id,revision=None,k=1):
 out=ROOT/f'reports/fresh_{name}_generations.jsonl'
 old=read(out) if out.exists() else [];by={r['sample_id']:r for r in old}
 kwargs=dict(revision=revision) if revision else dict(local_files_only=True)
 tok=AutoTokenizer.from_pretrained(model_id,**kwargs);model=AutoModelForSeq2SeqLM.from_pretrained(model_id,**kwargs).to('cuda:0').eval()
 for s in rows:
  if s['sample_id'] in by:
   prior=by[s['sample_id']]
   if prior['input_sha256']!=digest(s['input_vi']) or prior['model_id']!=str(model_id) or prior['revision']!=revision:raise ValueError('Stale source or generator')
   continue
  x=tok('sentence-paraphrase: '+s['input_vi'],return_tensors='pt',truncation=False)
  if x['input_ids'].shape[1]>512:raise ValueError('Generator input too long')
  with torch.inference_mode():y=model.generate(**{a:b.to('cuda:0') for a,b in x.items()},num_beams=5,num_return_sequences=k,do_sample=False,max_new_tokens=512,early_stopping=True)
  texts=tok.batch_decode(y,skip_special_tokens=True)
  candidates=[dict(text=norm(t),complete=tok.eos_token_id in ids.tolist()) for t,ids in zip(texts,y) if norm(t)]
  r=dict(sample_id=s['sample_id'],input_sha256=digest(s['input_vi']),candidates=candidates,model_id=str(model_id),revision=revision)
  out.parent.mkdir(parents=True,exist_ok=True)
  with out.open('a',encoding='utf-8') as f:f.write(json.dumps(r,ensure_ascii=False)+'\n')
  by[s['sample_id']]=r
  if len(by)%20==0:print('Fresh generation',name,len(by),'/',len(rows),flush=True)
 del model;gc.collect();torch.cuda.empty_cache();return by

def main():
 freeze=json.loads((ROOT/'reports/model_freeze.json').read_text())
 checkpoint=ROOT/'artifacts/stage_b/best'
 for name,h in freeze['files'].items():
  if sha(checkpoint/name)!=h:raise ValueError('Frozen evaluator changed')
 rows=read(ROOT/'data/fresh_test.jsonl')
 if len(rows)!=240 or len({s['work_id'] for s in rows})!=12:raise ValueError('Fresh test incomplete')
 base=generate(rows,'base',BASE,REV,3)
 # Attach the prior private ViSP notebook output as input. Verify the exact generator.
 choices=list(Path('/kaggle/input').rglob('model.safetensors'))
 choices=[p.parent for p in choices if p.parent.name=='best' and p.parent.parent.name=='lr_1e-05' and p.stat().st_size==903834408]
 if not choices:raise RuntimeError('Prior full ViSP checkpoint is missing from notebook inputs')
 fine_dir=choices[0]
 if sha(fine_dir/'model.safetensors')!='db9ff2cef0885c53e5e042c437ed4d7adf7b8bce0e0d0a89fd29ac5ac99dbebd':raise ValueError('Prior generator hash mismatch')
 fine=generate(rows,'finetuned',fine_dir,k=1)
 scorer=VietnameseEvaluator(checkpoint);threshold=json.loads((checkpoint/'gate.json').read_text())['selected']['threshold'];outputs=[]
 for s in rows:
  b=[c['text'] for c in base[s['sample_id']]['candidates'] if c['complete']]
  f=[c['text'] for c in fine[s['sample_id']]['candidates'] if c['complete']]
  options=list(dict.fromkeys([s['input_vi']]+b+f))
  scores=scorer.score_many([dict(source=s['input_vi'],candidate=t) for t in options])
  best=max(range(len(options)),key=lambda j:scores[j]['rank_score'])
  selected=best if scores[best]['rank_score']-scores[0]['rank_score']>threshold else 0
  systems=dict(identity=s['input_vi'],base_top1=b[0] if b else s['input_vi'],finetuned_top1=f[0] if f else s['input_vi'],new_evaluator_rerank=options[selected])
  for name,text in systems.items():
   outputs.append(dict(sample_id=s['sample_id'],work_id=s['work_id'],category=s['category'],system=name,input_vi=s['input_vi'],output_vi=text,context_used=False))
 write(ROOT/'reports/fresh_system_outputs.jsonl',outputs)
 del scorer;gc.collect();torch.cuda.empty_cache()
 teacher=Teacher()
 for i,r in enumerate(outputs):
  r.update(teacher.pair(r['input_vi'],r['output_vi']))
  r['changed']=norm(r['input_vi'])!=norm(r['output_vi'])
  if (i+1)%100==0:print('Fresh automatic teacher scoring',i+1,'/',len(outputs),flush=True)
 write(ROOT/'reports/fresh_automatic_scores.jsonl',outputs)
 summary={}
 for name in sorted({r['system'] for r in outputs}):
  rr=[r for r in outputs if r['system']==name]
  summary[name]=dict(n=len(rr),changed=sum(r['changed'] for r in rr),mean_fluency_delta_proxy=statistics.mean(r['fluency_target'] for r in rr if r['fluency_target'] is not None),mean_semantic_proxy=statistics.mean(r['semantic_target'] for r in rr))
 report=dict(fresh_sources=240,fresh_works=12,systems=summary,label_origin='automatic_proxy',human_validated=False,context_used=False,chinese_translation_adequacy='not measured; evaluation is relative to Vietnamese source',official_JFLEG=False,official_SEEDA=False,circularity='Teacher targets also supervised evaluator heads. Agreement with the teacher is not independent evidence of human naturalness.')
 save(ROOT/'reports/fresh_pipeline_report.json',report);print('Fresh pipeline complete',summary,flush=True)
if __name__=='__main__':main()
