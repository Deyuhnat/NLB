"""Vietnamese study views inspired by JFLEG/SEEDA; not official benchmark translations."""
from common import *
def main():
 for split in ['train','dev','test']:
  rows=read(ROOT/f'data/team_{split}.jsonl')
  write(ROOT/f'data/views/fluency_reference_{split}.jsonl',[
   dict(sample_id=r['sample_id'],work_id=r['work_id'],input_vi=r['input_vi'],references_vi=[r['reviewed_output_vi']],reference_origin=r['review_origin'],gold_fluency_reference=False,official_JFLEG=False) for r in rows])
  write(ROOT/f'data/views/system_comparison_{split}.jsonl',[
   dict(sample_id=r['sample_id'],work_id=r['work_id'],input_vi=r['input_vi'],outputs=r['candidates'],historical_choice=r['reviewed_output_vi'],independent_human_ratings=None,official_SEEDA=False) for r in rows])
 save(ROOT/'data/views/README.json',dict(purpose='Vietnamese fluency-reference and system-comparison views. ViSP paraphrases are positive semantic pairs, not automatic gold fluency ratings.',official_JFLEG=False,official_SEEDA=False,human_validated=False))
if __name__=='__main__':main()
