"""Build a readable handoff report from completed evidence, never placeholder results."""
import html,json
from common import *
def main():
 required=['artifacts/stage_a/training_proof.json','artifacts/stage_b/training_proof.json','artifacts/stage_b_no_visp/training_proof.json','reports/fresh_pipeline_report.json']
 for p in required:
  if not (ROOT/p).exists():raise RuntimeError('Missing completed evidence: '+p)
 a=json.loads((ROOT/required[0]).read_text());b=json.loads((ROOT/required[1]).read_text());c=json.loads((ROOT/required[2]).read_text())
 fresh=json.loads((ROOT/required[3]).read_text())
 sections=[]
 def table(headers,rows):
  return '<table><thead><tr>'+''.join('<th>'+html.escape(str(h))+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row)+'</tr>' for row in rows)+'</tbody></table>'
 sections.append('<h2>Đã thực hiện</h2><div class="flow"><div>ViSP train hợp lệ<br><b>'+str(a['trained_rows'])+' cặp</b></div><span>→</span><div>Full encoder<br>học giữ nghĩa</div><span>→</span><div>697 nguồn nhóm<br>full fine-tune evaluator</div><span>→</span><div>Chọn bằng 141 dev<br>khóa model → đánh giá</div></div>')
 sections.append('<p>Model ViSP cũ sinh phương án diễn đạt. Model mới chấm và xếp hạng các phương án. Hai checkpoint có nhiệm vụ và trọng số khác nhau.</p>')
 sections.append('<h2>Bằng chứng huấn luyện</h2>'+table(['Mục','Kết quả'],[
  ['ViSP train đã xử lý',a['trained_rows']],['Stage A optimizer steps',a['optimizer_steps']],['Tất cả tham số encoder được mở học',a['all_encoder_parameters_trainable']],['Hash trước/sau Stage A khác nhau',a['before_sha256']!=a['after_sha256']],['Nguồn train của nhóm',b['source_count']],['Stage B optimizer steps',b['optimizer_steps']],['Đối chứng bỏ nền ViSP',c['completed']]]))
 chart=[]
 for name,proof in [('Có nền ViSP',b),('Không có nền ViSP',c)]:
  for r in proof['history']:chart.append([name,r['epoch'],f"{r['weak_preference_accuracy']:.4f}",f"{r['fluency_proxy_mae']:.4f}",f"{r['semantic_proxy_mae']:.4f}"])
 sections.append('<h2>So sánh trên dev</h2>'+table(['Nhánh','Epoch','Khớp preference yếu','MAE fluency proxy','MAE semantic proxy'],chart))
 sections.append('<p>Những số này so với lựa chọn lịch sử và teacher tự động. Chúng chưa thể thay thế xác nhận độc lập của người đọc.</p>')
 gate_path=ROOT/'reports/dev_calibration.json'
 if gate_path.exists():
  gate=json.loads(gate_path.read_text())['selected']
  sections.append('<h2>Hành vi bộ chọn hiện tại</h2>'+table(['Mục','Kết quả'],[
   ['Ngưỡng rank margin chọn trên dev',gate['threshold']],['Số nguồn dev được sửa',gate['changes']],['Khớp lựa chọn lịch sử trên dev',f"{gate['weak_choice_match']:.4f}"]]))
  if gate['changes']==0:sections.append('<p class="notice"><b>Gate hiện giữ câu gốc trên toàn bộ dev.</b> Bộ chọn ưu tiên identity; kết quả này chưa chứng minh khả năng tự động sửa câu tốt hơn. Các head fluency/semantic vẫn xuất điểm proxy cho application. So sánh rank giữa các phương án của cùng một input; các số này chưa được người đọc hiệu chuẩn.</p>')
 semantic_rows=[]
 for split in ['validation','test']:
  raw_path=ROOT/f'reports/stage_a_{split}_full.json';fixed_path=ROOT/f'reports/stage_a_{split}_nonidentity.json'
  if raw_path.exists():
   raw=json.loads(raw_path.read_text())
   semantic_rows.append([split,'Raw: còn đáp án trùng input',raw['n'],f"{raw['r_at_1']:.5f}",f"{raw['mrr']:.5f}"])
  if fixed_path.exists():
   fixed=json.loads(fixed_path.read_text())
   semantic_rows.append([split,'Loại đáp án trùng token input',fixed['n_evaluated'],f"{fixed['r_at_1']:.5f}",f"{fixed['mrr']:.5f}"])
 if semantic_rows:
  sections.append('<h2>Chẩn đoán giữ nghĩa trên ViSP</h2>'+table(['Split','Cách tính','Cặp được chấm','R@1','MRR'],semantic_rows))
  sections.append('<p>Các cặp thuận–nghịch khiến raw retrieval có thể tìm được đáp án giống hệt input. Bản loại trùng là phép chẩn đoán bổ sung sau khi khóa model, không được dùng để tune model. Pool gồm 1.024 dòng và còn nhiều dòng cùng nhóm paraphrase; các số này không phải điểm độ tự nhiên của người đọc.</p>')
 systems=fresh['systems'];extended=ROOT/'reports/fresh_extended_comparison.json'
 if extended.exists():systems=json.loads(extended.read_text())['systems']
 rr=[]
 for name,r in systems.items():
  flu=r.get('mean_fluency_delta_proxy',r.get('mean_fluency_proxy'));sem=r.get('mean_semantic_proxy')
  rr.append([name,r['n'],r.get('changed',r.get('changes')),f'{flu:.4f}',f'{sem:.4f}'])
 sections.append('<h2>Test mới: 240 câu / 12 truyện</h2>'+table(['Hệ thống','Câu','Đã sửa','Fluency delta proxy ↑','Semantic proxy ↑'],rr))
 categories=sorted({r['category'] for r in read(ROOT/'data/fresh_test.jsonl')})
 sections.append('<p>Thể loại theo nguồn thực tế: '+html.escape(', '.join(categories))+'. Không tự đổi tên thể loại để khớp với các thể loại chưa có dữ liệu.</p>')
 if extended.exists():
  by_category=json.loads(extended.read_text()).get('per_category',{})
  category_rows=[]
  for category,systems_by_category in by_category.items():
   for system,result in systems_by_category.items():category_rows.append([category,system,result['n'],result['changes'],f"{result['mean_fluency_proxy']:.4f}",f"{result['mean_semantic_proxy']:.4f}"])
  sections.append('<h2>Kết quả theo thể loại thực tế</h2>'+table(['Thể loại','Hệ thống','Câu','Đã sửa','Fluency proxy ↑','Semantic proxy ↑'],category_rows))
 sections.append('<p>Fluency delta là ước lượng chênh lệch NLL; semantic là độ tương đồng teacher. Teacher có tham gia tạo nhãn train, vì vậy đây là đánh giá tự động có phụ thuộc teacher. Không đo độ trung thành với nguyên tác tiếng Trung. Đánh giá bởi người đọc: <b>đang chờ</b>.</p>')
 agreement=ROOT/'reports/surrogate_teacher_agreement.json'
 if agreement.exists():
  values=json.loads(agreement.read_text());agreement_rows=[]
  for model,subsets in values['results'].items():
   for subset,axes in subsets.items():
    for axis,r in axes.items():
     fmt=lambda x:'N/A' if x is None else f'{x:.4f}'
     agreement_rows.append([model,subset,axis,r['n'],fmt(r.get('mae')),fmt(r.get('constant_baseline_mae')),fmt(r.get('spearman'))])
  sections.append('<h2>Độ khớp của evaluator với teacher trên test</h2>'+table(['Model','Tập con','Trục','Cặp','MAE ↓','MAE baseline hằng ↓','Spearman'],agreement_rows))
  sections.append('<p>Đã gộp các output trùng của nhiều hệ thống thành một cặp input–candidate, đồng thời báo riêng các phương án có chỉnh sửa. Baseline hằng dự đoán fluency delta=0 và semantic=1. Đây là độ khớp với teacher tự động cùng họ đã dùng để supervision, chưa phải tương quan với đánh giá độc lập của người đọc.</p>')
  sem=values['results']['full_visp_team']['all_unique_pairs']['semantic']
  if sem['mae']>=sem['constant_baseline_mae']:
   sections.append('<p class="notice"><b>Surrogate hiện chưa vượt baseline hằng ở trục semantic.</b> Bàn giao model như một kết quả nghiên cứu đã chạy thật, chưa đủ bằng chứng để dùng làm metric chính. Bộ teacher tham chiếu tự động được cung cấp trong teacher.py; xác nhận bởi người đọc vẫn đang chờ.</p>')
 sections.append('<h2>Application nhận gì?</h2><p>Checkpoint encoder + heads + gate; inference.py; API mẫu; manifest/checksum; báo cáo và log. Input là source/candidate bằng tiếng Việt. Output gồm rank_score, fluency_delta_proxy, semantic_preservation_proxy; grammar_score=null, human_validated=false, context_used=false.</p>')
 sections.append('<h2>Phạm vi JFLEG/SEEDA</h2><p>Các view fluency-reference và system-comparison dùng cấu trúc phục vụ nghiên cứu tiếng Việt. Không gọi đây là JFLEG/SEEDA chính thức được retrain và không coi paraphrase ViSP là nhãn fluency chuẩn.</p>')
 style='body{font:16px/1.65 system-ui,sans-serif;color:#162939;background:#eff4f8;margin:0}main{max-width:1120px;margin:32px auto;background:white;padding:38px;border-radius:18px}h1{font-size:32px}h2{margin-top:32px}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:10px;text-align:left;border-bottom:1px solid #dce4eb}th{background:#e5f1ed}.flow{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.flow div{background:#e5f1ed;padding:16px;border-radius:10px;flex:1;min-width:180px}.notice{padding:14px;background:#fff1ce;border-left:4px solid #c38b08}'
 content='<!doctype html><html lang="vi"><meta charset="utf-8"><title>Vietnamese Evaluator — Bàn giao</title><style>'+style+'</style><main><h1>Vietnamese Evaluator — Bàn giao phần của Huy</h1><p><b>Bộ dữ liệu gồm 1.050 câu đã được nhóm review</b></p><p class="notice">Đã hoàn tất huấn luyện theo proof đi kèm. Các chỉ số chất lượng hiện có nguồn tự động; xác nhận độc lập bởi người đọc vẫn đang chờ.</p>'+''.join(sections)+'</main></html>'
 (ROOT/'reports/BAO_CAO_BAN_GIAO.html').write_text(content,encoding='utf-8')
 print('Built evidence-based handoff report')
if __name__=='__main__':main()
