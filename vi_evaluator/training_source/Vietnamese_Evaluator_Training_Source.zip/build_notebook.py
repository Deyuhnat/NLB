"""Self-contained private Kaggle GPU notebook. No database credentials embedded."""
import base64,hashlib,io,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def cell(kind,text):
 return dict(cell_type=kind,metadata={},source=text.splitlines(True),**(dict(outputs=[],execution_count=None) if kind=='code' else {}))
def main():
 files=[p.name for p in ROOT.glob('*.py') if p.name not in ['build_notebook.py','collect_fresh.py']]
 files+=['config.json','requirements.txt','README.md']
 files += [str(p.relative_to(ROOT)).replace('\\','/') for p in (ROOT/'tests').glob('*.py')]
 files += [str(p.relative_to(ROOT)).replace('\\','/') for p in (ROOT/'examples').glob('*.jsonl')]
 files += [str(p.relative_to(ROOT)).replace('\\','/') for p in (ROOT/'data').glob('team*.json*')]
 files += [f'data/preferences_{s}.jsonl' for s in ['train','dev','test']]
 files += ['data/teacher_manifest.json','data/visp_expected_manifest.json']
 for name in ['data/fresh_test.jsonl','data/fresh_pilot.jsonl','private/fresh_collection_manifest.json','reports/fresh_data_lock.json']:
  if (ROOT/name).exists():files.append(name)
 buff=io.BytesIO()
 with zipfile.ZipFile(buff,'w',zipfile.ZIP_DEFLATED) as z:
  for name in sorted(set(files)):z.write(ROOT/name,name)
 payload=buff.getvalue();(ROOT/'delivery/evaluator_source_bundle.zip').write_bytes(payload)
 bootstrap=f"""from pathlib import Path
import os,sys,subprocess,base64,hashlib,io,zipfile,json
os.environ['USE_TF']='0';os.environ['USE_FLAX']='0';os.environ['TOKENIZERS_PARALLELISM']='false'
payload=base64.b64decode({base64.b64encode(payload).decode()!r})
assert hashlib.sha256(payload).hexdigest()=={hashlib.sha256(payload).hexdigest()!r}
work=Path('/kaggle/working/vi_evaluator')
work.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(io.BytesIO(payload)) as z:
 assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
 z.extractall(work)
def run(*args):
 p=subprocess.Popen([sys.executable,'-u','-X','utf8',*args],cwd=work,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 for line in p.stdout:print(line,end='',flush=True)
 if p.wait():raise RuntimeError('Failed: '+' '.join(args))
run('-m','pip','install','--quiet','-r','requirements.txt')
import torch
assert torch.cuda.is_available(),'GPU must be enabled'
print('Torch',torch.__version__,'GPU',torch.cuda.get_device_name(0))
run('-m','unittest','discover','-s','tests','-v')
"""
 cells=[cell('markdown',"""# Vietnamese Evaluator: full ViSP foundation + reviewed team adaptation

**Bộ dữ liệu gồm 1.050 câu đã được nhóm review**

This private experiment trains a NEW evaluator, separate from the ViSP generator.
Stage A uses ALL eligible official ViSP training pairs after documented leakage quarantine.
Official validation/test are never training inputs. Stage B uses 697 train sources;
141 dev sources choose checkpoints/gate; 150 historical test sources are retrospective.
All axis targets are automatic teacher proxies. Historical choices are weak preferences,
not independent human ratings. This is not an official Vietnamese JFLEG or SEEDA release.
No context-aware or human-calibrated claim. GPU and Internet required.
"""),cell('code',bootstrap),cell('markdown','## 1. Verify pinned public corpus and frozen team data'),cell('code',"run('download_data.py')\nrun('export_views.py')"),
 cell('markdown','## 2. Full encoder foundation: every eligible ViSP training pair once\nQuarter checks use one pair per selected validation group. Final validation/test evaluate every eligible pair.'),
 cell('code',"run('train.py','a')"),
 cell('markdown','## 3. Full encoder adaptation on reviewed team data'),cell('code',"run('train.py','b')"),
 cell('markdown','## 4. Controlled ablation: same adaptation without ViSP foundation'),cell('code',"run('train.py','ablation')"),
 cell('markdown','## 5. Freeze dev policy, then open retrospective historical test'),cell('code',"run('evaluate.py')"),
 cell('markdown','## 6. Fresh Vietnamese pipeline comparison after model freeze'),cell('code',"run('fresh_pipeline.py')"),
 cell('markdown','## 7. Post-freeze diagnostics and portable output\nVerify exported tokenizers and remove exact-identity candidates from semantic retrieval diagnostics. These checks do not update model weights. Human confirmation remains pending.'),
 cell('code',"""run('saved_tokenizer_parity.py')
run('-m','unittest','discover','-s','tests','-p','test_retrieval_audit.py','-v')
run('retrieval_audit.py')
run('make_report.py')
run('package.py')
print((work/'reports/run_status.json').read_text())
""")]
 nb=dict(cells=cells,metadata=dict(kernelspec=dict(display_name='Python 3',language='python',name='python3'),language_info=dict(name='python'),kaggle=dict(isGpuEnabled=True,isInternetEnabled=True,accelerator='gpu')),nbformat=4,nbformat_minor=5)
 (ROOT/'delivery/Vietnamese_Evaluator_Kaggle.ipynb').write_text(json.dumps(nb,ensure_ascii=False),encoding='utf-8')
 print('Built',len(payload),'compressed bytes; notebook ready')
if __name__=='__main__':main()
