"""Resume this verified run using bounded HTTP ranges; URLs stay in memory."""
import json,sys,time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urljoin
import requests
from common import *
from download_artifacts import target
DEFER={'vi_evaluator/artifacts/stage_a/complete/encoder/model.safetensors','vi_evaluator/delivery/Vietnamese_Evaluator_Inference.zip'}
def get_range(session,url,start,end,total):
 for attempt in range(4):
  try:
   with session.get(url,headers={'Range':f'bytes={start}-{end}','Accept-Encoding':'identity'},timeout=(20,60)) as r:
    if r.status_code==206:
     if r.headers.get('Content-Range')!=f'bytes {start}-{end}/{total}':raise RuntimeError('Range identity mismatch')
    elif not (r.status_code==200 and start==0 and end==total-1):raise RuntimeError('Range request HTTP '+str(r.status_code))
    content=r.content;resolved=r.url
   if len(content)!=end-start+1:raise RuntimeError('Range length mismatch')
   return content,resolved
  except Exception as error:
   if attempt==3:raise RuntimeError('Range transfer failed: '+type(error).__name__) from None
   time.sleep(attempt+1)
def download(e):
 p=target(e)
 if p is None or e['fullPath'] in DEFER:return None
 n=int(e.get('contentLength',0));p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists() and p.stat().st_size==n:return dict(file=str(p.relative_to(ROOT)),bytes=n,sha256=sha(p),cached=True)
 tmp=p.with_suffix(p.suffix+'.download');offset=tmp.stat().st_size if tmp.exists() else 0
 if offset>n:raise ValueError('Partial file exceeds expected size')
 url=urljoin('https://www.kaggle.com',e['downloadUrl']);session=requests.Session()
 if offset:
  start=max(0,offset-1024);tail,url=get_range(session,url,start,offset-1,n)
  with tmp.open('rb') as f:f.seek(start);local=f.read(offset-start)
  if local!=tail:raise ValueError('Partial file does not match remote artifact')
 mode='ab' if offset else 'wb';last=offset
 with tmp.open(mode) as f:
  while offset<n:
   end=min(offset+16*1024*1024-1,n-1);block,url=get_range(session,url,offset,end,n);f.write(block);f.flush();offset=end+1
   if offset-last>=32*1024*1024 or offset==n:
    print('Range download',str(p.relative_to(ROOT)),offset,'/',n,flush=True);last=offset
 tmp.replace(p);session.close()
 return dict(file=str(p.relative_to(ROOT)),bytes=n,sha256=sha(p),resumed=True)
def main():
 payload=json.loads(sys.stdin.readline())
 if payload['kernelRun']['status']!='COMPLETE':raise RuntimeError('Archive must be COMPLETE')
 with ThreadPoolExecutor(max_workers=2) as pool:result=list(pool.map(download,payload['outputFiles']))
 save(ROOT/'verification/ranged_download.json',dict(run_id=payload['kernelRun']['id'],files=[r for r in result if r],deferred=list(sorted(DEFER)),reason='Foundation weights remain in archived Kaggle output; inference ZIP is rebuilt locally from verified application weights and reports'))
 print('RANGED ARTIFACT DOWNLOAD COMPLETE',flush=True)
if __name__=='__main__':main()
