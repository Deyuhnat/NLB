"""Real two-stage GPU training, full-pass accounting and resumable state."""
import argparse,contextlib,copy,gc,json,math,random,time
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from transformers import AutoModel,AutoTokenizer,get_linear_schedule_with_warmup
from common import *
from model import Evaluator,contrastive
from tokens import TokenPairs,collate_pairs,select_validation

def device_batch(x,device):return {k:v.to(device) for k,v in x.items()}
def amp(device):return torch.autocast('cuda',dtype=torch.float16) if device.startswith('cuda') else contextlib.nullcontext()
def state_hash(module):
 import hashlib
 h=hashlib.sha256()
 for name,t in module.state_dict().items():h.update(name.encode());h.update(t.detach().cpu().contiguous().numpy().tobytes())
 return h.hexdigest()
def rng_state():
 return dict(python=random.getstate(),numpy=np.random.get_state(),torch=torch.get_rng_state(),cuda=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None)
def restore_rng(r):
 random.setstate(r['python']);np.random.set_state(r['numpy']);torch.set_rng_state(r['torch'].cpu())
 if r['cuda'] is not None:torch.cuda.set_rng_state_all([x.cpu() for x in r['cuda']])
def atomic_torch(path,obj):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.tmp');torch.save(obj,tmp);tmp.replace(p)
def save_latest(path,model,optimizer,scheduler,scaler,progress):
 atomic_torch(path,dict(model=model.state_dict(),optimizer=optimizer.state_dict(),scheduler=scheduler.state_dict(),scaler=scaler.state_dict(),rng=rng_state(),progress=progress))
def step(optimizer,scaler,model,n,scheduler=None):
 scaler.unscale_(optimizer)
 for p in model.parameters():
  if p.grad is not None:p.grad.div_(n)
 grad_norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
 if not torch.isfinite(grad_norm).item() and not scaler.is_enabled():raise RuntimeError('Nonfinite gradients in full precision')
 before=scaler.get_scale()
 scaler.step(optimizer);scaler.update();updated=scaler.get_scale()>=before
 if updated and scheduler is not None:scheduler.step()
 optimizer.zero_grad(set_to_none=True)
 return updated
def construct(source=None):
 c=config();kw={'revision':c['encoder_revision']} if source is None else {}
 source=source or c['encoder']
 tokenizer=AutoTokenizer.from_pretrained(source,**kw)
 encoder=AutoModel.from_pretrained(source,add_pooling_layer=False,**kw)
 return Evaluator(encoder),tokenizer
def save_model(path,model,tokenizer,metadata,heads=True):
 p=Path(path);p.mkdir(parents=True,exist_ok=True)
 model.encoder.save_pretrained(p/'encoder',safe_serialization=True);tokenizer.save_pretrained(p/'encoder')
 if heads:torch.save({'trunk':model.trunk.state_dict(),'heads':model.heads.state_dict()},p/'heads.pt')
 save(p/'model_card.json',metadata)

def retrieval(model,data,tokenizer,device,batch=32,pool=1024):
 model.eval();a=[];b=[];groups=[]
 with torch.inference_mode():
  for i in range(0,len(data),batch):
   x,y,g=collate_pairs([data[j] for j in range(i,min(i+batch,len(data)))],tokenizer.pad_token_id)
   with amp(device):u=model.embed(device_batch(x,device));v=model.embed(device_batch(y,device))
   a.append(u.cpu());b.append(v.cpu());groups.append(g)
 a=torch.cat(a);b=torch.cat(b);groups=torch.cat(groups);correct=0;rr=0.
 for i in range(0,len(data),pool):
  u=a[i:i+pool];v=b[i:i+pool];g=groups[i:i+pool];scores=u@v.T;positive=g[:,None].eq(g[None,:])
  top=scores.argmax(1);correct+=g[top].eq(g).sum().item()
  best=scores.masked_fill(~positive,-torch.inf).max(1).values
  rank=1+(scores>best[:,None]).sum(1);rr+=(1./rank).sum().item()
 return dict(n=len(data),pool_size=pool,r_at_1=correct/len(data),mrr=rr/len(data))

def probe_batch(model,data,tokenizer,device,choices):
 # Reserve optimizer-state headroom; probe performs no optimizer update.
 worst=int(np.argmax(np.maximum(data.offsets[:,1],data.offsets[:,3])))
 for batch in choices:
  try:
   torch.cuda.empty_cache();torch.cuda.reset_peak_memory_stats();model.train();model.zero_grad(set_to_none=True)
   x,y,g=collate_pairs([data[worst]]*batch,tokenizer.pad_token_id);g=torch.arange(batch,device=device)
   with amp(device):loss=contrastive(model.embed(device_batch(x,device)),model.embed(device_batch(y,device)),g)
   loss.backward();peak=torch.cuda.max_memory_allocated();total=torch.cuda.get_device_properties(device).total_memory
   model.zero_grad(set_to_none=True)
   if peak>total-3*1024**3:raise torch.cuda.OutOfMemoryError('Optimizer-state headroom')
   return batch,dict(batch=batch,peak_bytes=peak,total_bytes=total)
  except torch.cuda.OutOfMemoryError:
   model.zero_grad(set_to_none=True);gc.collect();torch.cuda.empty_cache()
 raise RuntimeError('No GPU batch fits; do not silently skip corpus')

def stage_a():
 c=config();seed_all(c['seed'])
 if not torch.cuda.is_available():raise RuntimeError('Full stage A requires GPU; CPU only for unit tests')
 device='cuda:0';model,tokenizer=construct();model.to(device)
 data=TokenPairs(ROOT/'data/visp_train.jsonl',tokenizer,c['max_tokens'])
 groups=select_validation(ROOT/'data/visp_validation.jsonl',c['stage_a']['validation_groups'])
 save(ROOT/'data/validation_selection.json',sorted(groups))
 val=TokenPairs(ROOT/'data/visp_validation.jsonl',tokenizer,c['max_tokens'],groups,one_per_group=True)
 out=ROOT/'artifacts/stage_a';out.mkdir(parents=True,exist_ok=True)
 latest=out/'latest.pt';micro,probe=probe_batch(model,data,tokenizer,device,c['stage_a']['micro_batches'])
 optimizer=torch.optim.AdamW(model.encoder.parameters(),lr=c['stage_a']['lr'],weight_decay=c['stage_a']['weight_decay'])
 updates=math.ceil(len(data)/c['stage_a']['optimizer_batch'])
 scheduler=get_linear_schedule_with_warmup(optimizer,int(updates*c['stage_a']['warmup_ratio']),updates)
 scaler=torch.amp.GradScaler('cuda')
 progress=dict(next_start=0,seen_samples=0,optimizer_steps=0,micro_batch=micro,history=[],before_encoder_sha256=state_hash(model.encoder))
 if latest.exists():
  checkpoint=torch.load(latest,map_location=device,weights_only=False)
  model.load_state_dict(checkpoint['model']);optimizer.load_state_dict(checkpoint['optimizer']);scheduler.load_state_dict(checkpoint['scheduler']);scaler.load_state_dict(checkpoint['scaler'])
  progress=checkpoint['progress'];micro=progress['micro_batch'];restore_rng(checkpoint['rng'])
 if not progress['history']:
  initial=retrieval(model,val,tokenizer,device,pool=c['stage_a']['retrieval_pool']);progress['initial_retrieval']=initial;print('Initial validation',initial,flush=True)
 seed_all(c['seed']);order=torch.randperm(len(data),generator=torch.Generator().manual_seed(c['seed'])).tolist()
 if latest.exists():restore_rng(checkpoint['rng'])
 model.train();optimizer.zero_grad(set_to_none=True);accumulated=0;loss_sum=0.;last_eval=progress['next_start'];started=time.perf_counter();grad_tensors=0
 for start in range(progress['next_start'],len(data),micro):
  ids=order[start:start+micro];x,y,g=collate_pairs([data[j] for j in ids],tokenizer.pad_token_id)
  with amp(device):loss=contrastive(model.embed(device_batch(x,device)),model.embed(device_batch(y,device)),g.to(device),c['stage_a']['temperature'])
  if not torch.isfinite(loss):raise RuntimeError('Nonfinite stage A loss')
  scaler.scale(loss*len(ids)).backward();accumulated+=len(ids);loss_sum+=float(loss.detach())*len(ids)
  grad_tensors=max(grad_tensors,sum(p.grad is not None for p in model.encoder.parameters()))
  progress['gradient_tensors']=max(progress.get('gradient_tensors',0),grad_tensors)
  progress['seen_samples']+=len(ids);progress['next_start']=start+len(ids)
  if accumulated>=c['stage_a']['optimizer_batch'] or progress['next_start']==len(data):
   updated=step(optimizer,scaler,model,accumulated,scheduler);accumulated=0
   progress['optimizer_steps']+=int(updated);progress['skipped_updates']=progress.get('skipped_updates',0)+int(not updated)
   if progress['skipped_updates']>20:raise RuntimeError('Repeated AMP skips; stop instead of traversing without updates')
   if progress['optimizer_steps']==10 and not progress.get('early_weight_update_verified'):
    changed=state_hash(model.encoder)!=progress['before_encoder_sha256']
    if not changed or optimizer.param_groups[0]['lr']<=0:raise RuntimeError('Early optimizer check failed: no encoder update or zero learning rate')
    progress['early_weight_update_verified']=True
    print('VERIFIED ENCODER UPDATE after 10 successful steps; lr',optimizer.param_groups[0]['lr'],flush=True)
   if updated and progress['optimizer_steps']%100==0:print('Stage A',progress['next_start'],'/',len(data),'steps',progress['optimizer_steps'],'loss',float(loss.detach()),'lr',optimizer.param_groups[0]['lr'],'skipped',progress['skipped_updates'],flush=True)
   if progress['next_start']-last_eval>=max(1,len(data)//4) or progress['next_start']==len(data):
    score=retrieval(model,val,tokenizer,device,pool=c['stage_a']['retrieval_pool'])
    progress['history'].append(dict(seen=progress['seen_samples'],steps=progress['optimizer_steps'],**score));save(out/'progress.json',progress)
    save_latest(latest,model,optimizer,scheduler,scaler,progress);last_eval=progress['next_start'];model.train()
    print('Stage A validation',score,flush=True)
 # Export only after the entire valid train corpus was traversed.
 if progress['seen_samples']!=len(data):raise RuntimeError('Stage A incomplete')
 card=dict(stage='A',training_scope='all eligible official ViSP train rows',raw_train_rows=c['visp_expected']['train'],trained_rows=len(data),optimizer_steps=progress['optimizer_steps'],all_encoder_parameters_trainable=all(p.requires_grad for p in model.encoder.parameters()),gradient_tensors=grad_tensors,encoder_tensors=len(list(model.encoder.parameters())),before_sha256=progress['before_encoder_sha256'],after_sha256=state_hash(model.encoder),validation_history=progress['history'],initial_validation=progress['initial_retrieval'],device=torch.cuda.get_device_name(0),seconds_this_session=time.perf_counter()-started,preflight=probe,checkpoint_selection='full epoch 1; quarter evaluations are diagnostics, exported weights have seen the complete eligible corpus')
 card['gradient_tensors']=progress.get('gradient_tensors',grad_tensors)
 card['early_weight_update_verified']=progress.get('early_weight_update_verified',False);card['skipped_amp_updates']=progress.get('skipped_updates',0);card['scheduler_steps']=scheduler.last_epoch
 if card['before_sha256']==card['after_sha256']:raise RuntimeError('Encoder did not change')
 save_model(out/'complete',model,tokenizer,card,heads=False);save(out/'training_proof.json',card)
 for split in ['validation','test']:
  full=TokenPairs(ROOT/f'data/visp_{split}.jsonl',tokenizer,c['max_tokens'])
  result=retrieval(model,full,tokenizer,device,pool=c['stage_a']['retrieval_pool']);save(ROOT/f'reports/stage_a_{split}_full.json',result);print('Full semantic evaluation',split,result,flush=True)
 print('STAGE A COMPLETE',len(data),flush=True)

class TeamRows:
 def __init__(self,split,tokenizer):
  samples=read(ROOT/f'data/team_{split}.jsonl');labels={(r['sample_id'],norm(r['candidate_vi'])):r for r in read(ROOT/f'data/team_labels_{split}.jsonl')};self.rows=[];self.excluded=[]
  for s in samples:
   preferred=s['reviewed_output_vi'];count=len(s['candidates'])
   for item in s['candidates']:
    texts=[s['input_vi'],preferred,item['text']]
    tokens=[tokenizer(t,truncation=False)['input_ids'] for t in texts]
    if max(map(len,tokens))>config()['max_tokens']:self.excluded.append(s['sample_id']);continue
    p=labels[s['sample_id'],norm(preferred)];a=labels[s['sample_id'],norm(item['text'])]
    self.rows.append(dict(sample_id=s['sample_id'],tokens=tokens,rank_mask=float(norm(preferred)!=norm(item['text'])),weight=1/count,
     preferred_labels=[p['fluency_target'],p['semantic_target']],alternative_labels=[a['fluency_target'],a['semantic_target']]))
  write(ROOT/f'data/team_token_excluded_{split}.jsonl',[{'sample_id':s} for s in sorted(set(self.excluded))])
  self.source_count=len({r['sample_id'] for r in self.rows})
 def __len__(self):return len(self.rows)
 def __getitem__(self,i):return self.rows[i]
def team_collate(rows,pad,device):
 def pack(index):
  seq=[r['tokens'][index] for r in rows];n=max(map(len,seq));ids=torch.full((len(rows),n),pad,dtype=torch.long);mask=torch.zeros_like(ids)
  for i,s in enumerate(seq):ids[i,:len(s)]=torch.tensor(s);mask[i,:len(s)]=1
  return device_batch(dict(input_ids=ids,attention_mask=mask),device)
 labels=torch.tensor([[float(v) if v is not None else float('nan') for v in r['preferred_labels']+r['alternative_labels']] for r in rows],device=device)
 return [pack(i) for i in range(3)],labels,torch.tensor([r['weight'] for r in rows],device=device),torch.tensor([r['rank_mask'] for r in rows],device=device)
def weighted_mean(values,weights,mask):
 w=weights*mask
 return (values*w).sum()/w.sum().clamp(min=1e-8)
def team_loss(p,a,labels,weights,rank_mask):
 rank=weighted_mean(F.softplus(a['rank']-p['rank']),weights,rank_mask)
 losses=[]
 for output,start in [(p,0),(a,2)]:
  for j,key in enumerate(['fluency','semantic']):
   target=labels[:,start+j];mask=torch.isfinite(target);target=torch.nan_to_num(target)
   values=F.smooth_l1_loss(output[key],target,reduction='none') if key=='fluency' else (output[key]-target)**2
   losses.append(weighted_mean(values,weights,mask))
 return .5*rank+.125*sum(losses)
def evaluate_team(model,data,tokenizer,device,batch=16):
 model.eval();correct=0.;denom=0.;fluency=[];semantic=[];losses=[]
 with torch.inference_mode():
  for i in range(0,len(data),batch):
   parts,y,w,mask=team_collate([data[j] for j in range(i,min(i+batch,len(data)))],tokenizer.pad_token_id,device)
   with amp(device):p=model(parts[0],parts[1]);a=model(parts[0],parts[2]);loss=team_loss(p,a,y,w,mask)
   correct+=((p['rank']>a['rank']).float()*mask*w).sum().item();denom+=(mask*w).sum().item();losses.append(float(loss))
   for output,col in [(p,0),(a,2)]:
    valid=torch.isfinite(y[:,col]);fluency.extend((output['fluency'][valid]-y[valid,col]).abs().cpu().tolist())
    valid=torch.isfinite(y[:,col+1]);semantic.extend((output['semantic'][valid]-y[valid,col+1]).abs().cpu().tolist())
 return dict(weak_preference_accuracy=correct/denom if denom else None,weighted_preference_denominator=denom,fluency_proxy_mae=float(np.mean(fluency)) if fluency else None,semantic_proxy_mae=float(np.mean(semantic)) if semantic else None,loss=float(np.mean(losses)),label_origin='automatic_proxy_and_legacy_inferred_preference',human_validated=False)

def stage_b(ablation=False):
 if not torch.cuda.is_available():raise RuntimeError('Full stage B requires GPU')
 c=config();seed_all(c['seed']);device='cuda:0';name='stage_b_no_visp' if ablation else 'stage_b'
 source=None if ablation else ROOT/'artifacts/stage_a/complete/encoder'
 if not ablation and not (source/'config.json').exists():raise RuntimeError('Complete full stage A first')
 model,tokenizer=construct(source);model.to(device)
 train=TeamRows('train',tokenizer);dev=TeamRows('dev',tokenizer)
 if train.source_count!=697 or dev.source_count!=141:raise ValueError('Some required team sources are not eligible; report rather than silently under-train')
 out=ROOT/'artifacts'/name;out.mkdir(parents=True,exist_ok=True)
 optimizer=torch.optim.AdamW([{'params':model.encoder.parameters(),'lr':c['stage_b']['encoder_lr']},{'params':list(model.trunk.parameters())+list(model.heads.parameters()),'lr':c['stage_b']['head_lr']}],weight_decay=.01)
 # Stage B micro-batch probing includes all four encoder forwards.
 batch=c['stage_b']['batch']
 while True:
  try:
   model.train();model.zero_grad(set_to_none=True);worst=sorted(train.rows,key=lambda r:max(map(len,r['tokens'])),reverse=True)[:batch]
   parts,y,w,m=team_collate(worst,tokenizer.pad_token_id,device)
   with amp(device):loss=team_loss(model(parts[0],parts[1]),model(parts[0],parts[2]),y,w,m)
   loss.backward();model.zero_grad(set_to_none=True);break
  except torch.cuda.OutOfMemoryError:
   model.zero_grad(set_to_none=True);torch.cuda.empty_cache();batch//=2
   if batch<4:raise
 seed_all(c['seed'])
 steps=math.ceil(len(train)/32)*c['stage_b']['epochs'];scheduler=get_linear_schedule_with_warmup(optimizer,int(.1*steps),steps);scaler=torch.amp.GradScaler('cuda')
 progress=dict(epoch=0,next_start=0,seen_rows=0,steps=0,best_key=None,bad_epochs=0,history=[],micro_batch=batch,before_sha256=state_hash(model.encoder))
 latest=out/'latest.pt'
 if latest.exists():
  checkpoint=torch.load(latest,map_location=device,weights_only=False);model.load_state_dict(checkpoint['model']);optimizer.load_state_dict(checkpoint['optimizer']);scheduler.load_state_dict(checkpoint['scheduler']);scaler.load_state_dict(checkpoint['scaler']);progress=checkpoint['progress'];batch=progress['micro_batch'];restore_rng(checkpoint['rng'])
 for epoch in range(progress['epoch'],c['stage_b']['epochs']):
  order=torch.randperm(len(train),generator=torch.Generator().manual_seed(c['seed']+epoch)).tolist();model.train();optimizer.zero_grad(set_to_none=True);acc=0
  start_at=progress['next_start'] if epoch==progress['epoch'] else 0
  for start in range(start_at,len(train),batch):
   ids=order[start:start+batch];parts,y,w,m=team_collate([train[j] for j in ids],tokenizer.pad_token_id,device)
   with amp(device):loss=team_loss(model(parts[0],parts[1]),model(parts[0],parts[2]),y,w,m)
   if not torch.isfinite(loss):raise RuntimeError('Nonfinite stage B loss')
   scaler.scale(loss*len(ids)).backward();acc+=len(ids);progress['seen_rows']+=len(ids);progress['next_start']=start+len(ids)
   if acc>=32 or progress['next_start']==len(train):
    updated=step(optimizer,scaler,model,acc,scheduler);acc=0;progress['steps']+=int(updated)
    progress['skipped_updates']=progress.get('skipped_updates',0)+int(not updated)
    if progress['skipped_updates']>20:raise RuntimeError('Repeated stage B AMP skips')
    if progress['steps']==10 and not progress.get('early_weight_update_verified'):
     if state_hash(model.encoder)==progress['before_sha256'] or optimizer.param_groups[0]['lr']<=0:raise RuntimeError('Stage B early encoder update check failed')
     progress['early_weight_update_verified']=True;print(name,'VERIFIED ENCODER UPDATE after 10 successful steps',flush=True)
    if progress['steps']%100==0:print(name,'epoch',epoch+1,'rows',start,'/',len(train),'loss',float(loss.detach()),flush=True)
    if progress['steps']%250==0:save_latest(latest,model,optimizer,scheduler,scaler,progress)
  metrics=evaluate_team(model,dev,tokenizer,device,batch=batch);key=(metrics['weak_preference_accuracy'] or 0.,-metrics['loss']);progress['history'].append(dict(epoch=epoch+1,**metrics))
  if progress['best_key'] is None or tuple(key)>tuple(progress['best_key']):
   progress['best_key']=key;progress['bad_epochs']=0
   metadata=dict(stage=name,team_train_sources=train.source_count,team_train_rows=len(train),team_dev_sources=dev.source_count,epoch=epoch+1,metrics=metrics,encoder_before_sha256=progress['before_sha256'],encoder_after_sha256=state_hash(model.encoder),all_encoder_parameters_trainable=all(p.requires_grad for p in model.encoder.parameters()),label_origin=c['label_origin'],human_validated=False,context_used=False,token_limit=c['max_tokens'],foundation='initial MiniLM' if ablation else 'stage A full ViSP train epoch')
   save_model(out/'best',model,tokenizer,metadata)
  else:progress['bad_epochs']+=1
  progress['epoch']=epoch+1;progress['next_start']=0;save_latest(latest,model,optimizer,scheduler,scaler,progress);save(out/'progress.json',progress);print(name,'DEV',metrics,flush=True)
  if progress['bad_epochs']>=c['stage_b']['patience']:break
 if not (out/'best/model_card.json').exists():raise RuntimeError('No stage B checkpoint exported')
 save(out/'training_proof.json',dict(completed=True,source_count=train.source_count,train_rows=len(train),history=progress['history'],optimizer_steps=progress['steps'],label_origin=c['label_origin'],human_validated=False))
 print(name,'COMPLETE',flush=True)

def main():
 p=argparse.ArgumentParser();p.add_argument('stage',choices=['a','b','ablation']);a=p.parse_args()
 if a.stage=='a':stage_a()
 else:stage_b(a.stage=='ablation')
if __name__=='__main__':main()
